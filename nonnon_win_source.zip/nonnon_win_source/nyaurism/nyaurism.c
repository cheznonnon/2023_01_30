// Nonnon Nyaurism
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef NONNON_APPS




//#define N_MEMORY_DEBUG




#include "../nonnon/game/timegettime.c"

#include "../nonnon/neutral/bmp/all.c"
#include "../nonnon/neutral/string_path.c"
#include "../nonnon/neutral/wav.c"

// [!] : before "win.c"
#include "../nonnon/win32/ole/IDropTarget.c"

// [!] : before "win_txtbox.c"
#include "../nonnon/win32/win_inputpopup.c"

#include "../nonnon/win32/explorer.c"
#include "../nonnon/win32/gdi/bitmap.c"
#include "../nonnon/win32/gdi/doublebuffer.c"
#include "../nonnon/win32/resource.c"
#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_button.c"
#include "../nonnon/win32/win_scroller.c"
#include "../nonnon/win32/win_separator.c"
#include "../nonnon/win32/win_sizegrip.c"
#include "../nonnon/win32/win_titlemenu.c"
#include "../nonnon/win32/win_txtbox.c"

#include "../nonnon/project/macro.c"
#include "../nonnon/project/ini2wav.c"




// [!] : Components

#define N_NYAURISM_EXT_WAV n_posix_literal( ".wav\0\0" )


#ifndef NONNON_APPS

#define N_APPS_ICON_OFFSET_NYAURISM ( 0 )

#endif // #ifndef NONNON_APPS


static n_wav  n_nyaurism_wav;
static n_bool n_nyaurism_mix_onoff = n_false;

static n_win_txtbox n_nyaurism_list;


#include "./nyaurism_formatter.c"
#include "./nyaurism_plotter.c"
#include "./nyaurism_plugin.c"
#include "./nyaurism_resizer.c"
#include "./nyaurism_waveinout.c"


#define H_PLOTTER   n_nyaurism_hgui[ 0 ]
#define H_LINE      n_nyaurism_hgui[ 1 ]
#define GUI_MAX                      2

#define H_BTN_CLEAR n_nyaurism_hbtn[ 0 ]
#define H_BTN_PLAY  n_nyaurism_hbtn[ 1 ]
#define H_BTN_REC   n_nyaurism_hbtn[ 2 ]
#define H_BTN_MIX   n_nyaurism_hbtn[ 3 ]
#define H_BTN_SIZE  n_nyaurism_hbtn[ 4 ]
#define H_BTN_SAVE  n_nyaurism_hbtn[ 5 ]
#define BTN_MAX                      6

#define H_LIST        n_nyaurism_list
#define H_SIZEGRIP    n_nyaurism_hsizegrip
#define H_SIZEGRIP_DK n_nyaurism_hsizegrip_dark


#define H_SCR_HERTZ n_nyaurism_hscr[  0 ]
#define H_SCR_LEFT  n_nyaurism_hscr[  1 ]
#define H_SCR_RIGHT n_nyaurism_hscr[  2 ]
#define SCR_MAX                       3




// [!] : Constants

#define APPNAME_LITERAL n_posix_literal( "Nyaurism" )


#define MSG_LINE        "Plugin Option"
#define MSG_HERTZ       "Freq."
#define MSG_LEFT        "Left"
#define MSG_RIGHT       "Right"

#define TIMERMSEC       33


// [!] : Window

static HWND           n_nyaurism_hsizegrip;
static HWND           n_nyaurism_hsizegrip_dark;
static HWND           n_nyaurism_hgui[ GUI_MAX ];
static n_win_button   n_nyaurism_hbtn[ BTN_MAX ];
static n_win_scroller n_nyaurism_hscr[ SCR_MAX ];


// [!] : App instance

static n_posix_char *n_nyaurism_exename;
static n_posix_char *n_nyaurism_wavname;

static n_bool        n_nyaurism_play_onoff = n_false;
static n_bool        n_nyaurism_rec__onoff = n_false;

static n_wav         n_nyaursim_wav_partial;
static n_wav        *n_nyaursim_wav_target;

static n_bool        n_nyaursim_resize           = n_true;
static n_bool        n_nyaurism_sysmenu_is_first = n_true;

static UINT          n_nyaurism_timer_id = 0;

static WNDPROC       n_nyaurism_flickerfree_func = NULL;




// internal
n_posix_char*
n_nyaurism_newname( void )
{

	n_posix_char *dir = n_string_path_folder_current_new();
	n_posix_char *tmp = n_string_path_tmpname_new_literal( ".wav" );
	n_posix_char *nam = n_string_path_make_new( dir, tmp );

	n_string_path_make( dir, tmp, nam );

	n_string_path_free( dir );
	n_string_path_free( tmp );
	//n_string_path_free( nam );


	return nam;
}

// internal
void
n_nyaurism_newfile( HWND hwnd, const n_posix_char *name )
{

	n_project_pleasewait_on( hwnd );

	if (
		( n_wav_load( &n_nyaurism_wav, name ) )
		&&
		( n_ini2wav_load( name, &n_nyaurism_wav ) )
	)
	{

		static n_bool is_first = n_true;

		if ( is_first )
		{

			is_first = n_false;

			n_wav_new_by_sample( &n_nyaurism_wav, 44100 );

			n_string_path_free( n_nyaurism_wavname );
			n_nyaurism_wavname = n_nyaurism_newname();

		}

	} else {

		n_string_path_free( n_nyaurism_wavname );
		n_nyaurism_wavname = n_string_path_ext_mod_new( name, N_NYAURISM_EXT_WAV );

	}

	n_project_pleasewait_off( hwnd );


	{

		n_posix_char *s = n_string_carboncopy( n_nyaurism_wavname );

		n_string_replace( s, s, N_STRING_BSLASH, N_STRING_SLASH );

		n_win_hwndprintf_literal( hwnd, "%s - %s", s, APPNAME_LITERAL );

		n_memory_free( s );

	}

//n_win_hwndprintf( hwnd, "%lu", N_WAV_MSEC( &n_nyaurism_wav ) );

	return;
}

// internal
void
n_nyaurism_save( HWND hwnd, n_wav *wav )
{

	n_bool ret = n_wav_save( wav, n_nyaurism_wavname );
	if ( ret )
	{
		n_project_dialog_info( hwnd, n_project_string_error );
	} else {
		n_nyaurism_wav.channel = wav->channel;
		n_nyaurism_wav.bit     = wav->bit;
		n_nyaurism_wav.rate    = wav->rate;

		n_explorer_refresh( n_false );
	}


	return;
}

// internal
void
n_nyaurism_resize( HWND hwnd )
{

	const n_bool redraw = n_true;


	n_type_gfx ctl,ico,m;
	n_win_stdsize( hwnd, &ctl, &ico, &m );

	n_type_gfx gap_maclike = H_BTN_CLEAR.maclike_offset / 2;


	static n_bool is_first = n_true;

	int nwset = N_WIN_SET_DEFAULT;

	n_type_gfx csx = -1;
	n_type_gfx csy = -1;

	if ( is_first )
	{

		is_first = n_false;

		nwset = N_WIN_SET_CENTERING | N_WIN_SET_CLIPPING;

		csx = ( ico * 12 ) + ( gap_maclike * 7 );
		csy = ( ico * 10 ) + m;

		if ( ( n_sysinfo_version_10_or_later() )&&( 96 != n_win_dpi( hwnd ) ) ) { csx += 4; }

	} else {

		nwset = n_project_n_win_set();

	}


	n_win w;
	n_win_set( hwnd, &w, csx,csy, nwset );

	csx = w.csx - m;
	csy = w.csy - m;


	if ( w.state == SIZE_MAXIMIZED )
	{
		ShowWindow( H_SIZEGRIP   , SW_HIDE   );
		ShowWindow( H_SIZEGRIP_DK, SW_HIDE   );
	} else {
		ShowWindow( H_SIZEGRIP   , SW_NORMAL );
		ShowWindow( H_SIZEGRIP_DK, SW_NORMAL );
	}


	n_type_gfx unit_sx = csx / 3;
	n_type_gfx unit_sy = csy / 2;
	n_type_gfx psx     = csx;
	n_type_gfx psy     = unit_sy * 1;
	n_type_gfx lsx     = unit_sx * 1;
	n_type_gfx lsy     = unit_sy * 1;
	n_type_gfx ssx     = unit_sx * 2;
	n_type_gfx gap     = ico;//n_posix_max_n_type_gfx( 0, ssx - ( ico * 6 ) ) / 2;
	n_type_gfx gsz     = n_win_sizegrip_stdsize();
	n_type_gfx gx      = w.csx - gsz;
	n_type_gfx gy      = w.csy - gsz;

	n_type_gfx x = 0;
	n_type_gfx y = 0;

	x = gx;
	y = gy;
	n_win_move_simple( H_SIZEGRIP   ,  x,y, gsz,gsz, redraw );
	n_win_move_simple( H_SIZEGRIP_DK,  x,y, gsz,gsz, redraw );

	x = y = 0;
	n_win_move(  H_PLOTTER,   x,y, psx,psy, redraw ); y += unit_sy;
	n_win_move(  H_LIST.hwnd, x,y, lsx,lsy, redraw ); x += lsx;

	n_win_button_move( &H_BTN_CLEAR, x,y, ico,ico, redraw ); x += ico + gap_maclike;
	x += gap;
	n_win_button_move( &H_BTN_PLAY , x,y, ico,ico, redraw ); x += ico + gap_maclike;
	n_win_button_move( &H_BTN_REC  , x,y, ico,ico, redraw ); x += ico + gap_maclike;
	n_win_button_move( &H_BTN_MIX  , x,y, ico,ico, redraw ); x += ico + gap_maclike;
	x += gap;
	n_win_button_move( &H_BTN_SIZE , x,y, ico,ico, redraw ); x += ico + gap_maclike;
	n_win_button_move( &H_BTN_SAVE , x,y, ico,ico, redraw ); x += ico + gap_maclike; y += ico;

	x = lsx;
	n_win_move(  H_LINE,      x,y, ssx,ctl, redraw ); y += ctl;
	nwscr_move( &H_SCR_HERTZ, x,y, ssx,ctl, redraw ); y += ctl;
	nwscr_move( &H_SCR_LEFT,  x,y, ssx,ctl, redraw ); y += ctl;
	nwscr_move( &H_SCR_RIGHT, x,y, ssx,ctl, redraw ); y += ctl;

	n_win_scrollbar_draw_always( &H_SCR_HERTZ.scrollbar, n_true );
	n_win_scrollbar_draw_always( &H_SCR_LEFT .scrollbar, n_true );
	n_win_scrollbar_draw_always( &H_SCR_RIGHT.scrollbar, n_true );


	n_win_refresh( H_PLOTTER, n_false );


	n_win_txtbox_metrics_vertical_spacing( &H_LIST, H_LIST.font_pxl_sy + ( m * 2 ) );


	return;
}

// internal
void
n_nyaurism_enablewindow( n_bool onoff )
{

	//EnableWindow(  H_PLOTTER,   onoff );
	EnableWindow(  H_LIST.hwnd, onoff );
	nwscr_enable( &H_SCR_HERTZ, onoff );
	nwscr_enable( &H_SCR_LEFT,  onoff );
	nwscr_enable( &H_SCR_RIGHT, onoff );

	n_win_button_grayed_onoff( &H_BTN_CLEAR, onoff == n_posix_false );
	n_win_button_grayed_onoff( &H_BTN_SIZE,  onoff == n_posix_false );
	n_win_button_grayed_onoff( &H_BTN_PLAY,  onoff == n_posix_false );
	n_win_button_grayed_onoff( &H_BTN_REC,   onoff == n_posix_false );
	n_win_button_grayed_onoff( &H_BTN_MIX,   onoff == n_posix_false );
	n_win_button_grayed_onoff( &H_BTN_SAVE,  onoff == n_posix_false );


	if ( n_nyaurism_play_onoff ) { n_win_button_grayed_onoff( &H_BTN_PLAY, n_false ); }
	if ( n_nyaurism_rec__onoff ) { n_win_button_grayed_onoff( &H_BTN_REC,  n_false ); }


	return;
}

void
n_nyaurism_sysmenu( HWND hwnd, n_bool is_enable )
{

	HMENU hmenu = GetSystemMenu( hwnd, n_false );


	// [x] : Win7 : DeleteMenu() is not availble
	//
	//	a close button will be off after DeleteMenu()

	// [MSDN] : The Old New Thing

	if ( is_enable )
	{

		n_nyaursim_resize = n_true;

		n_win_style_add( hwnd, WS_MINIMIZEBOX | WS_MAXIMIZEBOX );

		EnableMenuItem( hmenu, SC_CLOSE, MF_BYCOMMAND | MF_ENABLED );

		ShowWindow( H_SIZEGRIP, SW_SHOW );

	} else {

		n_nyaursim_resize = n_false;

		n_win_style_del( hwnd, WS_MINIMIZEBOX | WS_MAXIMIZEBOX );

		EnableMenuItem( hmenu, SC_CLOSE, MF_BYCOMMAND | MF_DISABLED | MF_GRAYED );

		ShowWindow( H_SIZEGRIP, SW_HIDE );

	}


	return;
}

void
n_nyaurism_icon_add( void )
{

	n_win_icon_init_callback = n_project_system_icon_color;

	H_BTN_CLEAR.hicon = n_win_icon_init( n_nyaurism_exename, N_APPS_ICON_OFFSET_NYAURISM + 1, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_PLAY .hicon = n_win_icon_init( n_nyaurism_exename, N_APPS_ICON_OFFSET_NYAURISM + 2, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_REC  .hicon = n_win_icon_init( n_nyaurism_exename, N_APPS_ICON_OFFSET_NYAURISM + 4, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_MIX  .hicon = n_win_icon_init( n_nyaurism_exename, N_APPS_ICON_OFFSET_NYAURISM + 5, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_SIZE .hicon = n_win_icon_init( n_nyaurism_exename, N_APPS_ICON_OFFSET_NYAURISM + 6, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_SAVE .hicon = n_win_icon_init( n_nyaurism_exename, N_APPS_ICON_OFFSET_NYAURISM + 7, N_WIN_ICON_INIT_OPTION_RESOURCE );


	return;
}

void
n_nyaurism_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		n_win_txtbox_on_settingchange( &H_LIST );

		n_nyaurism_icon_add();

		n_win_button_on_settingchange( &H_BTN_CLEAR );
		n_win_button_on_settingchange( &H_BTN_SIZE  );
		n_win_button_on_settingchange( &H_BTN_PLAY  );
		n_win_button_on_settingchange( &H_BTN_REC   );
		n_win_button_on_settingchange( &H_BTN_MIX   );
		n_win_button_on_settingchange( &H_BTN_SAVE  );

		n_win_stdfont_init( &H_LINE, 1 );

		n_nyaurism_resize( hwnd );

	break;


	} // switch


}

LRESULT CALLBACK
n_nyaurism_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_wav       wav_prv;

	static HWAVEIN     hwi;
	static HWAVEOUT    hwo;
	static n_type_real hertz, left, right;

	static n_nyaurism_plugin plugin;


	static u32 timer = 0;

	static n_posix_char *title;


	static n_win_titlemenu  titlemenu;
	static n_win_simplemenu simplemenu;
	static n_win_simplemenu simplemenu_plotter;


	n_nyaurism_on_settingchange( hwnd, msg, wparam, lparam );


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_game_timegettime_init();

#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_init( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET

		n_win_ime_disable( hwnd );

		n_project_darkmode();
		//n_win_darkmode_onoff = n_true;

		n_wav_zero( &n_nyaurism_wav );
		n_wav_zero( &wav_prv );
		n_wav_zero( &n_nyaurism_plotter_selection_clip );
		n_wav_zero( &n_nyaursim_wav_partial );

		n_win_exedir2curdir();

		n_nyaurism_exename = n_win_exepath_new();

		n_win_button_zero( &H_BTN_CLEAR );
		n_win_button_zero( &H_BTN_SIZE  );
		n_win_button_zero( &H_BTN_PLAY  );
		n_win_button_zero( &H_BTN_REC   );
		n_win_button_zero( &H_BTN_MIX   );
		n_win_button_zero( &H_BTN_SAVE  );


		// Window

		n_win_init_literal( hwnd, "", "NYAURSIM_0_MAIN", "" );

		n_win_gui_literal( hwnd, CANVAS,  "",       &H_PLOTTER     );
		n_win_gui_literal( hwnd, CANVAS,  MSG_LINE, &H_LINE        );
		n_win_gui_literal( hwnd, CANVAS,  "",       &H_SIZEGRIP_DK );
		n_win_gui_literal( hwnd, VSCROLL, "",       &H_SIZEGRIP    );

		n_win_button_init( &H_BTN_CLEAR, hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_SIZE , hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_PLAY , hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_REC  , hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_MIX  , hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_SAVE , hwnd, N_STRING_EMPTY, PBS_NORMAL );

		{

			int style  = 0;

			style  |= N_WIN_TXTBOX_STYLE_LISTBOX;
			style  |= N_WIN_TXTBOX_STYLE_STRIPED;
			style  |= N_WIN_TXTBOX_STYLE_VSCROLL;

			int option = 0;

			option |= N_WIN_TXTBOX_OPTION_LISTBOX_KEEPSEL;

			if ( n_win_fluent_ui_onoff )
			{
				option |= N_WIN_TXTBOX_OPTION_LISTBOX_ROUNDRC;
			}

			n_win_txtbox_zero( &H_LIST );
			n_win_txtbox_init( &H_LIST, hwnd, style, option );
		}

		n_win_scroller_init_literal( &H_SCR_HERTZ, hwnd, MSG_HERTZ );
		n_win_scroller_init_literal( &H_SCR_LEFT , hwnd, MSG_LEFT  );
		n_win_scroller_init_literal( &H_SCR_RIGHT, hwnd, MSG_RIGHT );

		n_nyaurism_icon_add();


		// Style

		n_project_window_resizable( hwnd );

		n_win_style_add( H_SIZEGRIP, SBS_SIZEGRIP );


		n_win_simplemenu_zero( &simplemenu );
		n_win_simplemenu_init( &simplemenu );

		n_win_simplemenu_set( &simplemenu, 0, NULL, n_posix_literal( "[ ]Output ini2wav.ini" ), NULL );

		n_win_titlemenu_init_main( &titlemenu, hwnd, &simplemenu );


		n_win_simplemenu_zero( &simplemenu_plotter );
		n_win_simplemenu_init( &simplemenu_plotter );

		n_nyaurism_plotter_menu_init( &simplemenu_plotter );


		// Size

		n_win_stdfont_init( &H_LINE, 1 );

		n_nyaurism_resize( hwnd );


		// Init

		n_memory_zero( &plugin, sizeof( n_nyaurism_plugin ) );

		n_nyaurism_plugin_init( &H_LIST, &plugin );
		n_nyaurism_plugin_parameter_get( &H_LIST, &plugin, &hertz, &left, &right );


		n_win_scroller_scroll_parameter( &H_SCR_HERTZ, 1, 10, 22050, (int) hertz, n_true );
		n_win_scroller_scroll_parameter( &H_SCR_LEFT,  1, 10,   100, (int) left , n_true );
		n_win_scroller_scroll_parameter( &H_SCR_RIGHT, 1, 10,   100, (int) right, n_true );


		n_win_flickerfree_win_iconbutton_init( H_BTN_CLEAR.hwnd );
		n_win_flickerfree_win_iconbutton_init( H_BTN_SIZE .hwnd );
		n_win_flickerfree_win_iconbutton_init( H_BTN_PLAY .hwnd );
		n_win_flickerfree_win_iconbutton_init( H_BTN_REC  .hwnd );
		n_win_flickerfree_win_iconbutton_init( H_BTN_MIX  .hwnd );
		n_win_flickerfree_win_iconbutton_init( H_BTN_SAVE .hwnd );


		n_win_flickerfree_init( hwnd, &n_nyaurism_flickerfree_func );


		SetFocus( H_LIST.hwnd );


		{

			n_posix_char *cmdline = n_win_commandline_new();

#ifdef NONNON_APPS

			// [Needed] : for Nonnon Apps

			n_string_commandline_option( N_APPS_OPTION_NYAURISM, cmdline );

#endif // #ifdef NONNON_APPS

			n_nyaurism_newfile( hwnd, cmdline );

			n_string_path_free( cmdline );

		}


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }

		if ( H_PLOTTER != di->hwndItem ) { break; }

		n_nyaurism_plotter_redraw( H_PLOTTER );

	}
	break;


	case WM_SETFOCUS :
//n_win_hwndprintf_literal( hwnd, " %x ", wparam );

		SetFocus( H_LIST.hwnd );

	break;
/*
	case WM_ACTIVATE :
//n_win_hwndprintf_literal( hwnd, " %d ", wparam );

		if ( wparam == WA_CLICKACTIVE )
		{
			SetFocus( H_LIST.hwnd );
		}

	break;
*/

	case WM_SYSCOMMAND    :
	case WM_NCHITTEST     :
	case WM_NCRBUTTONDOWN :

		if ( n_nyaursim_resize == n_false ) { return 0; }

	break;


	case WM_SIZE :

		n_nyaurism_resize( hwnd );

	break;


	case WM_DROPFILES :
	{

		// [!] : anti-fault

		if ( ( n_nyaurism_play_onoff )||( n_nyaurism_rec__onoff ) ) { break; }


		n_posix_char *fname = n_win_dropfiles_multiple_new( hwnd, wparam );

		if ( n_nyaurism_mix_onoff )
		{

			n_wav w; n_wav_zero( &w );

			n_wav_load( &w, fname );

			n_wav_add( &w, &n_nyaurism_wav, 0.5, 0.5 );

			n_wav_free( &w );

		} else {

			n_nyaurism_newfile( hwnd, fname );

		}

		n_string_path_free( fname );


		n_nyaurism_plotter_redraw( H_PLOTTER );

	}
	break;


	case WM_MOUSEMOVE :

		if ( n_false == IsWindowVisible( H_PLOTTER ) ) { break; }

	break;

	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;


		if ( h == H_LIST.hwnd )
		{

			if ( wparam == WM_LBUTTONDBLCLK )
			{

				n_project_pleasewait_on( hwnd );

				n_nyaurism_plugin_call( &H_LIST, &plugin, &n_nyaurism_wav );

				n_project_pleasewait_off( hwnd );


				n_nyaurism_plotter_redraw( H_PLOTTER );

			} else
			if ( wparam == WM_LBUTTONDOWN )
			{

				n_nyaurism_plugin_parameter_get( &H_LIST, &plugin, &hertz, &left, &right );

				H_SCR_HERTZ.scrollbar.unit_pos = hertz;
				H_SCR_LEFT .scrollbar.unit_pos =  left;
				H_SCR_RIGHT.scrollbar.unit_pos = right;

				n_win_scroller_scroll_refresh( &H_SCR_HERTZ );
				n_win_scroller_scroll_refresh( &H_SCR_LEFT  );
				n_win_scroller_scroll_refresh( &H_SCR_RIGHT );

			}

		} else

		if ( h == n_win_scroller_scroll_hwnd( &H_SCR_HERTZ ) )
		{

			hertz = (n_type_real) wparam;

			n_win_hwndprintf_literal( H_SCR_HERTZ.value, "%3d Hz", (int) hertz );

			n_win_scrollbar_draw_always( &H_SCR_HERTZ.scrollbar, n_true );

			n_nyaurism_plugin_parameter_set( &H_LIST, &plugin, hertz, left, right );

		} else

		if ( h == n_win_scroller_scroll_hwnd( &H_SCR_LEFT ) )
		{

			left = (n_type_real) wparam;

			n_win_hwndprintf_literal( H_SCR_LEFT.value, "%3d %%", (int) left );

			n_win_scrollbar_draw_always( &H_SCR_LEFT.scrollbar, n_true );

			n_nyaurism_plugin_parameter_set( &H_LIST, &plugin, hertz, left, right );

		} else

		if ( h == n_win_scroller_scroll_hwnd( &H_SCR_RIGHT ) )
		{

			right = (n_type_real) wparam;

			n_win_hwndprintf_literal( H_SCR_RIGHT.value, "%3d %%", (int) right );

			n_win_scrollbar_draw_always( &H_SCR_RIGHT.scrollbar, n_true );

			n_nyaurism_plugin_parameter_set( &H_LIST, &plugin, hertz, left, right );

		} else

		if ( h == H_BTN_CLEAR.hwnd )
		{

			n_type_gfx x,sx; n_nyaurism_plotter_selection_pixel2sample( &x, &sx );
//n_win_hwndprintf_literal( hwnd, " Mute : %d %d : %d ", x, sx, N_WAV_COUNT( &n_nyaurism_wav ) );

			if ( sx == 0 ) { sx = N_WAV_COUNT( &n_nyaurism_wav ); }

			n_wav_mute( &n_nyaurism_wav, x, sx );

			n_nyaurism_plotter_selection_off();

			n_nyaurism_plotter_redraw( H_PLOTTER );

			SetFocus( H_LIST.hwnd );

		} else

		if ( h == H_BTN_SIZE.hwnd )
		{

			n_nyaurism_resizer_show
			(
				hwnd,
				n_nyaurism_hgui, GUI_MAX,
				n_nyaurism_hbtn, BTN_MAX,
				n_nyaurism_hscr, SCR_MAX
			);

		} else

		if ( h == H_BTN_PLAY.hwnd )
		{

			if ( n_nyaurism_play_onoff ) { timer = 0; break; }


			n_type_gfx x,sx; n_nyaurism_plotter_selection_pixel2sample( &x, &sx );

			if ( sx == 0 )
			{
				n_nyaursim_wav_target = &n_nyaurism_wav;
			} else {
				n_wav_new_by_sample( &n_nyaursim_wav_partial, sx );
				n_wav_copy( &n_nyaurism_wav, &n_nyaursim_wav_partial, x,sx, 0, 1.0,1.0, N_WAV_COPY_SET );
				n_nyaursim_wav_target = &n_nyaursim_wav_partial;
			}


			n_nyaurism_player_init( &hwo, n_nyaursim_wav_target );
			if ( hwo == NULL ) { break; }


			n_nyaurism_play_onoff = n_true;


			n_nyaurism_sysmenu_is_first = n_true;


			H_BTN_PLAY.hicon = n_win_icon_init( n_nyaurism_exename, N_APPS_ICON_OFFSET_NYAURISM + 3, N_WIN_ICON_INIT_OPTION_RESOURCE );
			n_nyaurism_enablewindow( n_false );


			n_nyaurism_player_go( &hwo, n_nyaursim_wav_target );


			timer = n_posix_tickcount();

			if ( n_nyaurism_timer_id == 0 ) { n_nyaurism_timer_id = n_win_timer_id_get(); }
			n_win_timer_init( hwnd, n_nyaurism_timer_id, TIMERMSEC );


			n_string_path_free( title );
			title = n_win_text_new( hwnd );

		} else

		if ( h == H_BTN_REC.hwnd )
		{

			// [x] : Windows cannot do playback and recording together


			if ( n_nyaurism_rec__onoff ) { timer = 0; break; }


			n_type_gfx x,sx; n_nyaurism_plotter_selection_pixel2sample( &x, &sx );

			if ( sx == 0 )
			{
				n_nyaursim_wav_target = &n_nyaurism_wav;
			} else {
				n_wav_new_by_sample( &n_nyaursim_wav_partial, sx );
				n_wav_copy( &n_nyaurism_wav, &n_nyaursim_wav_partial, x,sx, 0, 1.0,1.0, N_WAV_COPY_SET );
				n_nyaursim_wav_target = &n_nyaursim_wav_partial;
			}


			n_nyaurism_recorder_init( &hwi, n_nyaursim_wav_target );
			if ( hwi == NULL ) { break; }

			if ( n_nyaurism_mix_onoff )
			{
				n_wav_carboncopy( n_nyaursim_wav_target, &wav_prv );
			}


			n_nyaurism_rec__onoff = n_true;


			n_nyaurism_sysmenu_is_first = n_true;


			H_BTN_REC.hicon = n_win_icon_init( n_nyaurism_exename, N_APPS_ICON_OFFSET_NYAURISM + 3, N_WIN_ICON_INIT_OPTION_RESOURCE );
			n_nyaurism_enablewindow( n_false );


			n_string_path_free( title );
			title = n_win_text_new( hwnd );


			{ // Countdown

			n_win_button_grayed_onoff( &H_BTN_REC, n_true );

			int i = 0;
			n_posix_loop
			{

				n_win_hwndprintf_literal( hwnd, "Ready : %d", 3 - i );

				n_posix_sleep( 1000 );

				i++;
				if ( i >= 3 ) { break; }
			}

			n_win_button_grayed_onoff( &H_BTN_REC, n_false );

			} // Countdown


			n_nyaurism_recorder_go( &hwi, n_nyaursim_wav_target );


			timer = n_posix_tickcount();

			if ( n_nyaurism_timer_id == 0 ) { n_nyaurism_timer_id = n_win_timer_id_get(); }
			n_win_timer_init( hwnd, n_nyaurism_timer_id, TIMERMSEC );

		} else

		if ( h == H_BTN_MIX.hwnd )
		{

			int i = N_APPS_ICON_OFFSET_NYAURISM + 5;
			n_nyaurism_mix_onoff = n_win_button_checklike( &H_BTN_MIX, i, i, n_nyaurism_mix_onoff );

			SetFocus( H_LIST.hwnd );

		} else

		if ( h == H_BTN_SAVE.hwnd )
		{

			n_nyaurism_formatter_show
			(
				hwnd,
				n_nyaurism_hgui, GUI_MAX,
				n_nyaurism_hbtn, BTN_MAX,
				n_nyaurism_hscr, SCR_MAX
			);

			SetFocus( H_LIST.hwnd );

		} else

		if ( h == simplemenu.hwnd )
		{

			if ( wparam == N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
			{
				//
			} else
			if ( wparam == 0 )
			{
				n_resource_save_literal( "NYAURSIM_INI", "DATA", "ini2wav.ini" );
			} //else

		}

	}
	break;

	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != n_nyaurism_timer_id ) { break; }


		u32 cur = n_posix_tickcount() - timer;
		if ( cur < ( N_WAV_MSEC( n_nyaursim_wav_target ) + TIMERMSEC ) )
		{

			n_type_gfx x; n_nyaurism_plotter_selection_pixel2sample( &x, NULL );
			x = (n_type_gfx) ( (n_type_real) x / ( (n_type_real) N_WAV_RATE( n_nyaursim_wav_target ) / 1000 ) );
			cur = x + cur;

			if ( n_nyaurism_sysmenu_is_first )
			{
				n_nyaurism_sysmenu_is_first = n_false;
				n_nyaurism_sysmenu( hwnd, n_false );
			}

			n_win_hwndprintf_literal( hwnd, "%d / %d", cur, N_WAV_MSEC( n_nyaursim_wav_target ) );

			n_nyaurism_plotter_draw( H_PLOTTER, cur );

			break;

		}


		if ( n_nyaurism_play_onoff )
		{

			n_nyaurism_play_onoff = n_false;
			n_win_timer_exit( hwnd, n_nyaurism_timer_id );

			n_nyaurism_sysmenu( hwnd, n_true );

			H_BTN_PLAY.hicon = n_win_icon_init( n_nyaurism_exename, N_APPS_ICON_OFFSET_NYAURISM + 2, N_WIN_ICON_INIT_OPTION_RESOURCE );

			n_nyaurism_enablewindow( n_true );

			n_nyaurism_player_exit( &hwo, n_nyaursim_wav_target );

		}

		if ( n_nyaurism_rec__onoff )
		{

			n_nyaurism_rec__onoff = n_false;
			n_win_timer_exit( hwnd, n_nyaurism_timer_id );

			n_nyaurism_sysmenu( hwnd, n_true );

			H_BTN_REC.hicon = n_win_icon_init( n_nyaurism_exename, N_APPS_ICON_OFFSET_NYAURISM + 4, N_WIN_ICON_INIT_OPTION_RESOURCE );

			n_nyaurism_enablewindow( n_true );

			n_nyaurism_recorder_exit( &hwi, n_nyaursim_wav_target );

			n_type_gfx x,sx; n_nyaurism_plotter_selection_pixel2sample( &x, &sx );

			if ( n_nyaurism_mix_onoff )
			{
				if ( sx == 0 )
				{
					n_wav_add( &wav_prv, &n_nyaurism_wav, 0.5, 0.5 );
					n_wav_free( &wav_prv );
				} else {
					n_wav_copy( n_nyaursim_wav_target, &n_nyaurism_wav, 0,sx, x, 1.0,1.0, N_WAV_COPY_SET );
				}
			} else {
				n_wav_copy( n_nyaursim_wav_target, &n_nyaurism_wav, 0,sx, x, 1.0,1.0, N_WAV_COPY_SET );
			}

		}


		// [Needed] : this position is important

		n_win_text_set( hwnd, title );

		n_nyaurism_plotter_redraw( H_PLOTTER );


		SetFocus( H_LIST.hwnd );

	break;


	case WM_CLOSE :

		if ( ( n_nyaurism_play_onoff )||( n_nyaurism_rec__onoff ) ) { return n_true; }


		ShowWindow( hwnd, SW_HIDE );


		n_nyaurism_plugin_exit( &plugin );


		n_nyaurism_formatter_hide
		(
			hwnd,
			n_nyaurism_hgui, GUI_MAX,
			n_nyaurism_hbtn, BTN_MAX,
			n_nyaurism_hscr, SCR_MAX
		);

		n_nyaurism_resizer_hide
		(
			hwnd,
			n_nyaurism_hgui, GUI_MAX,
			n_nyaurism_hbtn, BTN_MAX,
			n_nyaurism_hscr, SCR_MAX
		);


		n_wav_free( &n_nyaurism_wav );
		n_wav_free( &wav_prv );
		n_wav_free( &n_nyaurism_plotter_selection_clip );
		n_wav_free( &n_nyaursim_wav_partial );


		n_string_path_free( n_nyaurism_wavname );
		n_string_path_free( title   );


		n_game_timegettime_exit();


		n_win_flickerfree_win_iconbutton_exit( H_BTN_CLEAR.hwnd );
		n_win_flickerfree_win_iconbutton_exit( H_BTN_SIZE .hwnd );
		n_win_flickerfree_win_iconbutton_exit( H_BTN_PLAY .hwnd );
		n_win_flickerfree_win_iconbutton_exit( H_BTN_REC  .hwnd );
		n_win_flickerfree_win_iconbutton_exit( H_BTN_MIX  .hwnd );
		n_win_flickerfree_win_iconbutton_exit( H_BTN_SAVE .hwnd );

		n_win_button_exit( &H_BTN_CLEAR );
		n_win_button_exit( &H_BTN_SIZE  );
		n_win_button_exit( &H_BTN_PLAY  );
		n_win_button_exit( &H_BTN_REC   );
		n_win_button_exit( &H_BTN_MIX   );
		n_win_button_exit( &H_BTN_SAVE  );

		n_win_stdfont_exit( &H_LINE, 1 );


		n_win_txtbox_exit( &H_LIST );

		n_win_scroller_exit( &H_SCR_HERTZ );
		n_win_scroller_exit( &H_SCR_LEFT  );
		n_win_scroller_exit( &H_SCR_RIGHT );


		n_win_flickerfree_exit( hwnd, &n_nyaurism_flickerfree_func );


		n_win_titlemenu_exit( &titlemenu );

		n_win_simplemenu_exit( &simplemenu );

		n_win_simplemenu_exit( &simplemenu_plotter );


		n_string_path_free( n_nyaurism_exename );


#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_exit( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	case WM_KEYDOWN :
/*
		if ( wparam == VK_F1 )
		{
			n_win_simplemenu_show( &simplemenu_plotter, hwnd );
		}
*/
	break;


	} // switch


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret != 0 ) { return ret; }
	}


	if (
		( n_false == n_nyaurism_formatter_onoff )
		&&
		( n_false == n_nyaurism_resizer_onoff   )
	)
	{
		n_nyaurism_plotter_selection_proc( hwnd, msg, wparam, lparam, H_PLOTTER, &simplemenu_plotter );

		n_nyaurism_plotter_menu_proc( hwnd, msg, wparam, lparam, H_PLOTTER, &simplemenu_plotter );
	}


	n_win_txtbox_proc( hwnd, msg, wparam, lparam, &H_LIST );

	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_CLEAR );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_SIZE  );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_PLAY  );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_REC   );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_MIX   );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_SAVE  );

	n_win_separator_proc( hwnd, msg, wparam, lparam, H_LINE, PS_SOLID );

	n_win_scroller_proc( hwnd, msg, wparam, lparam, &H_SCR_HERTZ );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, &H_SCR_LEFT  );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, &H_SCR_RIGHT );

	n_win_sizegrip_proc( hwnd, msg, wparam, lparam, H_SIZEGRIP_DK );


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	{
		LRESULT ret = 0;
		if ( n_win_fake_win7_proc( hwnd, msg, wparam, lparam, &ret ) )
		{
			return ret;
		}
	}


	if ( n_nyaurism_formatter_onoff )
	{
		return n_nyaurism_formatter_wndproc
		(
			hwnd, msg, wparam, lparam,
			n_nyaurism_hgui, GUI_MAX,
			n_nyaurism_hbtn, BTN_MAX,
			n_nyaurism_hscr, SCR_MAX
		);
	} else 
	if ( n_nyaurism_resizer_onoff )
	{
		return n_nyaurism_resizer_wndproc
		(
			hwnd, msg, wparam, lparam,
			n_nyaurism_hgui, GUI_MAX,
			n_nyaurism_hbtn, BTN_MAX,
			n_nyaurism_hscr, SCR_MAX
		);
	} else {
		return DefWindowProc( hwnd, msg, wparam, lparam );
	}
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE hprv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, n_nyaurism_wndproc );
}

#endif // #ifndef NONNON_APPS




#undef H_PLOTTER
#undef H_LINE
#undef GUI_MAX

#undef H_BTN_CLEAR
#undef H_BTN_PLAY
#undef H_BTN_REC
#undef H_BTN_MIX
#undef H_BTN_SIZE
#undef H_BTN_SAVE
#undef BTN_MAX

#undef H_LIST
#undef H_SIZEGRIP
#undef H_SIZEGRIP_DK

#undef H_SCR_HERTZ
#undef H_SCR_LEFT
#undef H_SCR_RIGHT
#undef SCR_MAX


#undef APPNAME_LITERAL

#undef MSG_LINE
#undef MSG_HERTZ
#undef MSG_LEFT
#undef MSG_RIGHT

#undef TIMERMSEC

