// Nonnon Nyaurism
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/neutral/dir.c"
#include "../nonnon/neutral/ini.c"
#include "../nonnon/neutral/string_path.c"

#include "../nonnon/win32/win.c"

#include "../nonnon/project/macro.c"




#define N_NYAURISM_PLUGIN_EXT_DLL         n_posix_literal( ".dll\0\0" )

#define N_NYAURISM_PLUGIN_DIRNAME_LITERAL n_posix_literal( "toybox\\nyaurism" )
#define N_NYAURISM_PLUGIN_ININAME_LITERAL n_posix_literal( "nyaurism.ini" )
#define N_NYAURISM_PLUGIN_HERTZ_LITERAL   n_posix_literal( "hertz" )
#define N_NYAURISM_PLUGIN_LEFT_LITERAL    n_posix_literal( "left " )
#define N_NYAURISM_PLUGIN_RIGHT_LITERAL   n_posix_literal( "right" )

#define N_NYAURISM_PLUGIN_SINE            n_posix_literal( "Base - Sine" )
#define N_NYAURISM_PLUGIN_COSINE          n_posix_literal( "Base - Cosine" )
#define N_NYAURISM_PLUGIN_SQUARE          n_posix_literal( "Base - Square" )
#define N_NYAURISM_PLUGIN_SAWTOOTH        n_posix_literal( "Base - Sawtooth" )
#define N_NYAURISM_PLUGIN_SANDSTORM       n_posix_literal( "Base - Sand Storm" )
#define N_NYAURISM_PLUGIN_PINKNOISE       n_posix_literal( "Base - Pink Noise" )
#define N_NYAURISM_PLUGIN_MARSIAN         n_posix_literal( "Base - Marsian" )
#define N_NYAURISM_PLUGIN_DELAY           n_posix_literal( "Filter - Delay" )
#define N_NYAURISM_PLUGIN_DISTORTION      n_posix_literal( "Filter - Distortion" )
#define N_NYAURISM_PLUGIN_FADE            n_posix_literal( "Filter - Fade" )
#define N_NYAURISM_PLUGIN_FADE_IN         n_posix_literal( "Filter - Fade In" )
#define N_NYAURISM_PLUGIN_FADE_OUT        n_posix_literal( "Filter - Fade Out" )
#define N_NYAURISM_PLUGIN_FEEDBACK_L      n_posix_literal( "Filter - Feedback Left" )
#define N_NYAURISM_PLUGIN_FEEDBACK_R      n_posix_literal( "Filter - Feedback Right" )
#define N_NYAURISM_PLUGIN_MONAURAL        n_posix_literal( "Filter - Monaural" )
#define N_NYAURISM_PLUGIN_NORMALIZE       n_posix_literal( "Filter - Normalize" )
#define N_NYAURISM_PLUGIN_SMOOTHER        n_posix_literal( "Filter - Smoother" )
#define N_NYAURISM_PLUGIN_TREMOLO         n_posix_literal( "Filter - Tremolo" )
#define N_NYAURISM_PLUGIN_TONE_UP         n_posix_literal( "Tone - Up" )
#define N_NYAURISM_PLUGIN_TONE_DOWN       n_posix_literal( "Tone - Down" )
#define N_NYAURISM_PLUGIN_TONE_UPDOWN     n_posix_literal( "Tone - Up-Down" )
#define N_NYAURISM_PLUGIN_TONE_DOWNUP     n_posix_literal( "Tone - Down-Up" )




typedef struct {

	n_vector dll;
	n_vector hertz;
	n_vector left;
	n_vector right;

} n_nyaurism_plugin;




// internal
n_posix_char*
n_nyaurism_plugin_shortname( const n_posix_char *name )
{

	n_posix_char *ret = n_string_path_carboncopy( name );

	if ( n_string_path_ext_is_same( N_NYAURISM_PLUGIN_EXT_DLL, ret ) )
	{
		n_string_path_name( ret, ret );
		n_string_path_ext_del( ret );
	}


	return ret;
}

// internal
void
n_nyaurism_plugin_add( n_win_txtbox *list, n_nyaurism_plugin *p, n_ini *ini, const n_posix_char *name )
{
//return;

	const n_posix_char *key_hertz = N_NYAURISM_PLUGIN_HERTZ_LITERAL;
	const n_posix_char *key_left  = N_NYAURISM_PLUGIN_LEFT_LITERAL;
	const n_posix_char *key_right = N_NYAURISM_PLUGIN_RIGHT_LITERAL;
	const n_posix_char *val_hertz = n_posix_literal( "440" );
	const n_posix_char *val_left  = n_posix_literal( "50" );
	const n_posix_char *val_right = n_posix_literal( "50" );


	n_vector_add( &p->dll, 0, name );


	{

		n_posix_char hertz[ 100 ];
		n_posix_char left [ 100 ];
		n_posix_char right[ 100 ];


		n_ini_value_str( ini, name, key_hertz, val_hertz, hertz, 100 );
		n_ini_value_str( ini, name, key_left,  val_left,  left,  100 );
		n_ini_value_str( ini, name, key_right, val_right, right, 100 );

		n_vector_add( &p->hertz, 0, hertz );
		n_vector_add( &p->left,  0, left  );
		n_vector_add( &p->right, 0, right );

	}


	{

		n_posix_char *str = n_nyaurism_plugin_shortname( name );

		n_win_txtbox_line_set( list, list->txt.sy, str );

		n_string_path_free( str );

	}


	return;
}

void
n_nyaurism_plugin_init( n_win_txtbox *list, n_nyaurism_plugin *p )
{
//return;

	if ( p == NULL ) { return; }


	n_win_exedir2curdir();


	n_dir d; n_dir_zero( &d );
	{
		n_posix_char *dir = n_string_path_folder_current_new();
		n_posix_char *nam = n_string_path_make_new( dir, N_NYAURISM_PLUGIN_DIRNAME_LITERAL ) ;

		n_dir_load( &d, nam );
//n_posix_debug_literal( " %s : %d ", nam, n_dir_all( &d ) );

		n_string_path_free( dir );
		n_string_path_free( nam );
	}


	n_ini ini; n_ini_zero( &ini );
	{
		n_posix_char *dir = n_string_path_folder_current_new();
		n_posix_char *nam = n_string_path_make_new( dir, N_NYAURISM_PLUGIN_ININAME_LITERAL ) ;

		n_ini_load( &ini, N_NYAURISM_PLUGIN_ININAME_LITERAL );

		n_string_path_free( dir );
		n_string_path_free( nam );
	}


	n_vector_new( &p->dll   );
	n_vector_new( &p->hertz );
	n_vector_new( &p->left  );
	n_vector_new( &p->right );


	// Built-in Filters

	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_SINE );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_COSINE );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_SQUARE );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_SAWTOOTH );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_SANDSTORM );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_PINKNOISE );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_MARSIAN );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_DELAY );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_DISTORTION );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_FADE );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_FADE_IN );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_FADE_OUT );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_FEEDBACK_L );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_FEEDBACK_R );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_MONAURAL );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_NORMALIZE );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_SMOOTHER );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_TREMOLO );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_TONE_UP );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_TONE_DOWN );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_TONE_UPDOWN );
	n_nyaurism_plugin_add( list, p, &ini, N_NYAURISM_PLUGIN_TONE_DOWNUP );


	n_type_int i = 0;
	n_posix_loop
	{

		if ( i >= n_dir_all( &d ) ) { break; }

		// [!] : currently neutral/vector.c doesn't support double-NUL

		n_posix_char *ext = n_string_path_carboncopy( n_dir_ext( &d, i ) );

		if ( n_string_path_ext_is_same( N_NYAURISM_PLUGIN_EXT_DLL, ext ) )
		{

			n_posix_char *str = n_string_path_make_new( n_dir_path( &d, i ), n_dir_name( &d, i ) );

			HMODULE hmod = LoadLibrary( str );
			FARPROC func = GetProcAddress( hmod, "plugin_main" );

			if ( ( hmod != NULL )&&( func != NULL ) )
			{
				n_nyaurism_plugin_add( list, p, &ini, str );
			}

			FreeLibrary( hmod );

			n_string_path_free( str );

		}

		n_string_path_free( ext );

		i++;

	}


	n_win_txtbox_line_select( list, 0 );


	n_ini_free( &ini );
	n_dir_free( &d );


	i = 0;
	n_posix_loop
	{

		if ( i >= p->dll.sy ) { break; }

		n_posix_char *l = p->dll.line[ i ];

		if ( n_string_is_empty( l ) )
		{
			n_vector_del( &p->dll,   p->dll.sy   );
			n_vector_del( &p->hertz, p->hertz.sy );
			n_vector_del( &p->left,  p->left.sy  );
			n_vector_del( &p->right, p->right.sy );
			i--;
		}

		i++;

	}

//n_vector_save_literal( &p->dll, "dll.txt", N_STRING_CRLF );


	return;
}

n_type_int
n_nyaurism_plugin_index( n_win_txtbox *list, n_nyaurism_plugin *p )
{
//return 0;

	n_type_int i = 0;
	n_posix_loop
	{

		if ( i >= p->dll.sy ) { i = 0; break; }


		n_posix_char *f = n_win_txtbox_selection_new( list );
		n_posix_char *t = n_nyaurism_plugin_shortname( p->dll.line[ i ] );
//n_posix_debug_literal( "%s\n%s", f,t );

		n_bool is_done = ( n_string_is_same( f, t ) );

		n_string_path_free( f );
		n_string_path_free( t );

		if ( is_done ) { break; }


		i++;

	}


	return i;
}

void
n_nyaurism_plugin_parameter_get( n_win_txtbox *list, n_nyaurism_plugin *p, n_type_real *hertz, n_type_real *left, n_type_real *right )
{
//return;

	if ( p == NULL ) { return; }


	n_type_int i = n_nyaurism_plugin_index( list, p );


	if ( hertz != NULL ) { (*hertz) = n_posix_atoi( p->hertz.line[ i ] ); }
	if ( left  != NULL ) { (*left ) = n_posix_atoi( p->left .line[ i ] ); }
	if ( right != NULL ) { (*right) = n_posix_atoi( p->right.line[ i ] ); }


	return;
}

void
n_nyaurism_plugin_parameter_set( n_win_txtbox *list, n_nyaurism_plugin *p, n_type_real hertz, n_type_real left, n_type_real right )
{
//return;

	if ( p == NULL ) { return; }


	n_type_int i = n_nyaurism_plugin_index( list, p );


	n_posix_char h[ 100 ];
	n_posix_char l[ 100 ];
	n_posix_char r[ 100 ];


	n_posix_sprintf_literal( h, "%d", (int) hertz );
	n_posix_sprintf_literal( l, "%d", (int) left  );
	n_posix_sprintf_literal( r, "%d", (int) right );


	n_vector_mod( &p->hertz, i, h );
	n_vector_mod( &p->left,  i, l );
	n_vector_mod( &p->right, i, r );


	return;
}

void
n_nyaurism_plugin_call( n_win_txtbox *list, n_nyaurism_plugin *p, n_wav *wav )
{
//return;

	if ( n_vector_error( &p->dll ) ) { return; }

	if ( n_wav_error_format( wav ) ) { return; }


	n_type_int i = n_nyaurism_plugin_index( list, p );

	n_type_real hertz, left, right;
	n_nyaurism_plugin_parameter_get( list, p, &hertz, &left, &right );

	left  /= 100;
	right /= 100;


	n_type_gfx x,sx; n_nyaurism_plotter_selection_pixel2sample( &x, &sx );
	if ( sx == 0 ) { sx = N_WAV_COUNT( wav ); }


	HMODULE hmod = LoadLibrary( p->dll.line[ i ] );
	FARPROC func = GetProcAddress( hmod, "plugin_main" );
	if ( func == NULL )
	{

		if ( n_string_is_same( N_NYAURISM_PLUGIN_SINE, p->dll.line[ i ] ) )
		{

			n_wav_sine_partial( wav, hertz, x,sx, left, right );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_COSINE, p->dll.line[ i ] ) )
		{

			n_wav_cosine_partial( wav, hertz, x,sx, left, right );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_SAWTOOTH, p->dll.line[ i ] ) )
		{

			n_wav_sawtooth_partial( wav, hertz, x,sx, left, right );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_SQUARE, p->dll.line[ i ] ) )
		{

			n_wav_square_partial( wav, hertz, x,sx, left, right );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_SANDSTORM, p->dll.line[ i ] ) )
		{

			n_wav_sandstorm_partial( wav, hertz, x,sx, left, right );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_PINKNOISE, p->dll.line[ i ] ) )
		{

			n_wav_pinknoise_partial( wav, hertz, x,sx, left, right );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_MARSIAN, p->dll.line[ i ] ) )
		{

			n_wav_marsian_partial( wav, hertz, x,sx, left, right );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_DELAY, p->dll.line[ i ] ) )
		{

			n_wav_delay_partial( wav, hertz, x,sx, left, right );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_DISTORTION, p->dll.line[ i ] ) )
		{

			n_wav_distortion_partial( wav, hertz, x,sx, left, right );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_FADE, p->dll.line[ i ] ) )
		{

			n_wav_fade_partial( wav, hertz, x,sx, left, right );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_FADE_IN, p->dll.line[ i ] ) )
		{

			n_wav_fade_in_partial( wav, hertz, x,sx, left, right );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_FADE_OUT, p->dll.line[ i ] ) )
		{

			n_wav_fade_out_partial( wav, hertz, x,sx, left, right );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_FEEDBACK_L, p->dll.line[ i ] ) )
		{

			n_wav_feedback_left_partial( wav, hertz, x,sx, left, right );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_FEEDBACK_R, p->dll.line[ i ] ) )
		{

			n_wav_feedback_right_partial( wav, hertz, x,sx, left, right );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_MONAURAL, p->dll.line[ i ] ) )
		{

			n_wav_monaural_partial( wav, hertz, x,sx, left, right );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_NORMALIZE, p->dll.line[ i ] ) )
		{

			n_wav_normalize_partial( wav, hertz, x,sx, left, right );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_SMOOTHER, p->dll.line[ i ] ) )
		{

			n_wav_smoother_partial( wav, x,sx );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_TREMOLO, p->dll.line[ i ] ) )
		{

			n_wav_tremolo_partial( wav, hertz, x,sx, left, right );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_TONE_UP, p->dll.line[ i ] ) )
		{

			n_wav_tone_up_partial( wav, hertz, x,sx, left, right );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_TONE_DOWN, p->dll.line[ i ] ) )
		{

			n_wav_tone_down_partial( wav, hertz, x,sx, left, right );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_TONE_UPDOWN, p->dll.line[ i ] ) )
		{

			n_wav_tone_updown_partial( wav, hertz, x,sx, left, right );

		} else
		if ( n_string_is_same( N_NYAURISM_PLUGIN_TONE_DOWNUP, p->dll.line[ i ] ) )
		{

			n_wav_tone_downup_partial( wav, hertz, x,sx, left, right );

		} else
		//
		{

			n_win_txtbox_reset( list );

			n_nyaurism_plugin_init( list, p );

		}

	} else {

		(*func)( wav->wh.dwBufferLength, (s16*) wav->wh.lpData, hertz, x,sx, left, right );

	}


	FreeLibrary( hmod );


	return;
}

void
n_nyaurism_plugin_exit( n_nyaurism_plugin *p )
{
//return;

	if ( p == NULL ) { return; }


	{ // INI Writer

	n_win_exedir2curdir();

	n_ini ini; n_ini_zero( &ini );

	n_ini_load( &ini, N_NYAURISM_PLUGIN_ININAME_LITERAL );


	n_posix_char *sct, *key, *val;

	n_type_int i = 0;
	while( p->dll.sy )
	{

		sct = p->dll.line[ i ];

		if ( n_false == n_string_is_empty( sct ) )
		{

			//n_ini_section_del( &ini, sct );
			n_ini_section_add( &ini, sct );


			key = N_NYAURISM_PLUGIN_HERTZ_LITERAL;
			val = p->hertz.line[ i ];

			n_ini_key_add_str( &ini, sct, key, val );


			key = N_NYAURISM_PLUGIN_LEFT_LITERAL;
			val = p->left.line[ i ];

			n_ini_key_add_str( &ini, sct, key, val );


			key = N_NYAURISM_PLUGIN_RIGHT_LITERAL;
			val = p->right.line[ i ];

			n_ini_key_add_str( &ini, sct, key, val );

		}


		i++;
		if ( i >= p->dll.sy ) { break; }
	}

	n_ini_save( &ini, N_NYAURISM_PLUGIN_ININAME_LITERAL );
	n_ini_free( &ini );

	} // INI Writer


	n_vector_free( &p->dll   );
	n_vector_free( &p->hertz );
	n_vector_free( &p->left  );
	n_vector_free( &p->right );


	return;
}

