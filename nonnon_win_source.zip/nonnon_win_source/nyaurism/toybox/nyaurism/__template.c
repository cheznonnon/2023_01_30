// Nonnon Wave
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "./_pcm.c"




void __stdcall
plugin_main( int byte, s16 *ptr, double hz, double left, double right )
{

	int count = n_pcm_maxcount( byte );


	//double a = SHRT_MAX;


	int x = 0;
	while( 1 )
	{

		double l,r;

		n_pcm_get( ptr, x, &l, &r );

		n_pcm_blend( ptr, x, 0.5, 0.5, l, r );

		n_pcm_set( ptr, x,  l,  r );


		x++;
		if ( x >= count ) { break; }
	}


	return;
}

