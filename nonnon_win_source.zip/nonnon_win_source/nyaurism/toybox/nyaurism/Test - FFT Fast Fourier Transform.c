// Nonnon Wave
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../../../nonnon/neutral/fft.c"
#include "../../../nonnon/neutral/txt.c"


#include "./_pcm.c"




void __stdcall
n_pcm_fft_div( n_fft *l, n_fft *r, int maxcount, double ratio )
{

	n_fft c = { ratio, ratio };


	int i = 1;
	while( 1 )
	{

		l[ i ] = n_fft_div( l[ i ], c );
		r[ i ] = n_fft_div( r[ i ], c );


		i++;
		if ( i >= maxcount ) { break; }
	}


	return;
}

void __stdcall
n_pcm_fft_test( n_fft *l, n_fft *r, int maxcount )
{

	// [!]
	//
	//	this will be 430.6640625 Hz
	//
	//	volume limit is [ max / 2 ]
	//	maybe symmetry is needed


	double bin = (double) 440 / ( (double) 44100 / maxcount );
	int    e   = (int) trunc( bin );
	double arg = bin - abs( bin );
	double a   = SHRT_MAX / 2;

	n_fft c = { arg, a };

//c = n_fft_cartesian2polar( c );

	l[ maxcount - e ] = l[ e ] = c;
	r[ maxcount - e ] = r[ e ] = c;

	l[ maxcount - e ].y *= -1;
	r[ maxcount - e ].y *= -1;


	return;
}

void __stdcall
n_pcm_fft_passfilter( n_fft *l, n_fft *r, int maxcount )
{

	// [x] : data will be broken between samples

	// [!] : human recognition
	//
	//	20Hz to 20,000Hz


	int halfcount = maxcount / 2;


	double bin    = (double) 44100 / maxcount;
	double bin_hi = (double) 10000 / bin;
	double bin_lo = (double)   100 / bin;


	n_fft c = { 0, 0 };


	int i = 1;
	while( 1 )
	{

		if ( ( i < bin_lo )||( i > bin_hi ) )
		{
			l[ maxcount - i ] = l[ i ] = c;
			r[ maxcount - i ] = r[ i ] = c;
		}



		i++;
		if ( i >= halfcount ) { break; }
	}


	return;
}

void __stdcall
plugin_main( int byte, s16 *ptr, double hz, u32 x, u32 sx, double left, double right )
{

	u32 count = sx;


	// [Mechanism]
	//
	//	multiplier of 2 only : 2 4 8 16 32...
	//	+1 for nyquist frequency

	u32 sample = pow( 2, 10 + 1 );


	n_fft *l = n_memory_new_closed( sample * sizeof( n_fft ) );
	n_fft *r = n_memory_new_closed( sample * sizeof( n_fft ) );

	// [Needed] : zero-clear is important

	n_fft_bulk_zero( l, sample );
	n_fft_bulk_zero( r, sample );


	n_posix_bool debug_onoff = n_posix_true;

	n_txt txt; n_txt_zero( &txt );

	if ( debug_onoff ) { n_txt_new( &txt ); }


	u32 offset = x;
	while( 1)
	{

		// Phase 1 : Input

		u32 i = 0;
		u32 j = offset;
		while( 2 )
		{

			if ( i >= sample ) { break; }
			if ( j >= count  ) { break; }

			if ( x < count )
			{
				n_pcm_get( ptr, j, &l[ i ].x, &r[ i ].x );
			} else {
				l[ i ].x = r[ i ].x = 0;
			}

			i++;
			j++;

		}


		// Phase 2 : Window

		n_fft_window( l, sample, N_FFT_WINDOW_RECTANGULAR );
		n_fft_window( r, sample, N_FFT_WINDOW_RECTANGULAR );


		// Phase 3 : FFT

		n_fft_codec( l, sample, N_FFT_CODEC_ENCODE );
		n_fft_codec( r, sample, N_FFT_CODEC_ENCODE );

		if ( debug_onoff )
		{

			n_posix_char str[ 100 ];

			u32 i = 0;
			while( 1 )
			{

				n_fft_debug_sample( l, r, i, str );

				n_txt_add( &txt, txt.sy, str );

				i++;
				if ( i >= sample ) { break; }
			}

		}


		// Phase 4 : Process

		//n_pcm_fft_test( l, r, sample );
		//n_pcm_fft_div( l, r, sample, 5 );

		//n_pcm_fft_passfilter( l, r, sample );


		// Phase 5 : iFFT

		n_fft_codec( l, sample, N_FFT_CODEC_DECODE );
		n_fft_codec( r, sample, N_FFT_CODEC_DECODE );


		// Phase 6 : Output

		i = 0;
		j = offset;
		while( 2 )
		{

			if ( i >= sample ) { break; }
			if ( j >= count  ) { break; }

			if ( x < count )
			{
				n_pcm_set( ptr, j, l[ i ].x, r[ i ].x );
			} else {
				break;
			}

			i++;
			j++;

		}


		offset += sample;
		if ( offset >= count ) { break; }
	}


	if ( debug_onoff )
	{
		n_txt_save_literal( &txt, "./toybox/nyaurism/fft_debug.txt" );
		n_txt_free( &txt );
	}


	n_memory_free_closed( l );
	n_memory_free_closed( r );


	return;
}

