// Nonnon Typing
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef NONNON_APPS




//#define N_MEMORY_DEBUG




#include "../nonnon/game/timegettime.c"


#include "../nonnon/win32/win.c"
#include "../nonnon/win32/gdi.c"

#include "../nonnon/game/transition.c"


#include "../nonnon/project/macro.c"




typedef struct {

	n_type_gfx   size;

	UINT         timer_id;
	n_type_real  percent;
	n_bmp        bmp_buf;
	n_bmp        bmp_old;
	n_bmp        bmp_new;

	n_posix_char str_key[ 100 ];
	n_type_gfx   size_font;

	int          rapid_fire;

} n_typing;

#define n_typing_zero( p ) n_memory_zero( p, sizeof( n_typing ) )


static n_typing n_typing_instance;




#include "midi.c"




void
n_typing_input( int vk, n_posix_char *str_ret )
{

	BYTE         key[ 256 ]; GetKeyboardState( key );
	n_posix_char str[ 100 ];

#ifdef UNICODE

	ToUnicode( vk,0,key, str,100, 0 );

#else // #ifdef UNICODE

	WORD w;
	ToAscii  ( vk,0,key, &w, 0 );
	str[ 0 ] = w;
	str[ 1 ] = N_STRING_CHAR_NUL;

	// [x] : Buggy : ANSI version on NT : invalid character will be returned

	if ( n_sysinfo_version_nt() )
	{
		wchar_t wstr[ 100 ];
		ToUnicode( vk,0,key, wstr,100, 0 );
		if ( wstr[ 0 ] == L'\0' ) { return; }
	}

#endif // #ifdef UNICODE

//n_posix_debug_literal( " %d ", str[ 0 ] );

//n_posix_debug_literal( "%d : %d : %d : %x", vk, ImmGetVirtualKey( p->hwnd ), n_win_is_input( VK_CONVERT ), (int) str[ 0 ] );

	if ( n_string_is_empty( str ) ) { return; }


	if ( 0x08 == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x08 : BS

	} else
	if ( 0x09 == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x09 : TAB

	} else
	if ( 0x0d == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x0d CR

	} else
	if ( 0x1b == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x1b ESC

	} else
	if ( 0x03 == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x03 End of Text

	} else
	if ( 0x16 == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x16 Synchronous Idle

	} else
	//
	{

		n_posix_sprintf_literal( str_ret, "%s", str );

	}


	return;
}

void
n_typing_gdi_make( n_bmp *bmp, n_posix_char *str, n_type_gfx size, n_type_gfx size_font )
{

	n_gdi gdi; n_gdi_zero( &gdi );


	gdi.sx                  = size;
	gdi.sy                  = size;
	gdi.scale               = N_GDI_SCALE_AUTO;
	gdi.style               = N_GDI_DEFAULT;
	gdi.layout              = N_GDI_LAYOUT_HORIZONTAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base                = n_posix_literal( "" );
	gdi.base_index          = 0;
	gdi.base_color_bg       = n_win_darkmode_systemcolor_colorref2argb( COLOR_WINDOW );
	gdi.base_color_fg       = n_bmp_rgb( 255,255,255 );
	gdi.base_style          = N_GDI_BASE_SOLID;
	gdi.base_unit           = 0;

	gdi.frame_style         = N_GDI_FRAME_NOFRAME;
	gdi.frame_round         = 0;

	gdi.text                = str;
	gdi.text_font           = n_project_stdfont();
	gdi.text_size           = size_font;
	gdi.text_style          = N_GDI_TEXT_SMOOTH;

	if ( n_win_is_input( 'F' ) )
	{
		gdi.text_color_main     = n_win_dwm_windowcolor_arranged();
	} else
	if ( n_win_is_input( 'J' ) )
	{
		gdi.text_color_main     = n_bmp_hue_wheel_tweak_pixel( n_win_dwm_windowcolor_arranged(), 32 );
	} else {
		gdi.text_color_main     = n_win_darkmode_systemcolor_colorref2argb( COLOR_BTNTEXT );
	}

	gdi.text_color_gradient = n_bmp_rgb( 255,255,255 );
	gdi.text_color_shadow   = n_bmp_rgb(  10, 10, 10 );
	gdi.text_color_contour  = n_bmp_rgb(  10, 10, 10 );
	gdi.text_color_sink_tl  = n_bmp_rgb(  10, 10, 10 );
	gdi.text_color_sink_br  = n_bmp_rgb(  10, 10, 10 );
	gdi.text_fxsize1        = 0;
	gdi.text_fxsize2        = 0;


	n_bmp_free( bmp );
	n_gdi_bmp( &gdi, bmp );


	return;
}

void
n_typing_resize( n_typing *p, HWND hwnd )
{

	n_type_gfx desktop_sx, desktop_sy;
	n_win_desktop_size( &desktop_sx, &desktop_sy );

//desktop_sx = 640; desktop_sy = 480; // [!] : VGA

	p->size = (n_type_gfx) ( (n_type_real) n_posix_min( desktop_sx, desktop_sy ) * 0.33 );
	p->size = n_posix_max( 256, p->size );


	int nws = N_WIN_SET_DEFAULT;

	static n_posix_bool is_first = n_posix_true;

	if ( is_first )
	{
		is_first = n_posix_false;
		nws = N_WIN_SET_CENTERING;
	}

	n_win_set( hwnd, NULL, p->size,p->size, nws );


	n_typing_gdi_make( &p->bmp_new, N_STRING_EMPTY, p->size, p->size );
	n_typing_gdi_make( &p->bmp_buf, N_STRING_EMPTY, p->size, p->size );


	return;
}

void
n_typing_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_typing *p )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }

		n_win_timer_exit( hwnd, timer_id );

		n_project_darkmode();

		n_typing_resize( p, hwnd );

	break;


	} // switch


}

LRESULT CALLBACK
n_typing_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_typing *p = &n_typing_instance;


	n_typing_on_settingchange( hwnd, msg, wparam, lparam, p );


	switch( msg ) {


	case WM_CREATE :

		// Global

		n_game_timegettime_init();

		n_win_exedir2curdir();

		n_project_darkmode();
		//n_win_darkmode_onoff = n_true;

		n_win_ime_disable( hwnd );

		n_hmidiout_init();


		n_typing_zero( p );

		p->size = 256;


		// Window

		n_win_init_literal( hwnd, "Nonnon Typing", "NTYPING_MAIN_ICON", "" );


		// Style

		n_win_style_new( hwnd, N_WS_FIXEDWINDOW );
		n_win_sysmenu_disable( hwnd, 0,0,1, 0,1, 0, 0 );

		p->timer_id = n_win_timer_id_get();


		// Size

		n_typing_resize( p, hwnd );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

		n_typing_gdi_make( &p->bmp_buf, n_project_string_go, p->size, p->size / 4 );
		n_gdi_bitmap_draw( hwnd, &p->bmp_buf, 0,0,p->size,p->size, 0,0 );

	break;


	case WM_TIMER :

		if ( wparam == 0 ) { break; }

		if ( p->timer_id == wparam )
		{
//n_win_debug_count( hwnd );

			if ( p->percent == 0 )
			{
				//n_typing_gdi_make( &p->bmp_old, p->str_key, p->size, p->size_font );
				//n_bmp_flush_fastcopy( &p->bmp_old, &p->bmp_new );

				static n_bool is_first = n_true;
				if ( is_first )
				{
					is_first = n_false;
					n_typing_gdi_make( &p->bmp_old, 0, p->size, p->size_font );
				}

				n_typing_gdi_make( &p->bmp_new, p->str_key, p->size, p->size_font );

				static int alternate = 0;

				if ( alternate & 1 )
				{
					n_typing_midi_note_on( p, 64 );
				} else {
					n_typing_midi_note_on( p, 48 );
				}

				alternate++;
			}

			n_posix_bool ret = n_game_transition
			(
				&p->bmp_buf,
				&p->bmp_old,
				&p->bmp_new,
				200,
				&p->percent,
				//N_GAME_TRANSITION_NOTHING
				//N_GAME_TRANSITION_FADE
				N_GAME_TRANSITION_SCROLL_U
			);

			if ( ret )
			{
				n_bmp_flush_fastcopy( &p->bmp_new, &p->bmp_old );

				n_win_timer_exit( hwnd, p->timer_id );
			}

			n_gdi_bitmap_draw( hwnd, &p->bmp_buf, 0,0,p->size,p->size, 0,0 );

		}

	break;


	case WM_KEYDOWN :
	{

		int vk = (int) wparam;
//n_win_hwndprintf_literal( hwnd, "%d", vk );break;


		if ( p->rapid_fire == vk )
		{
			break;
		} else {
			if ( vk != VK_SHIFT )
			{
				p->rapid_fire = vk;
			}
		}


		n_string_truncate( p->str_key );


		p->size_font = p->size;

		if (
			( vk == VK_TAB )
			||
			( vk == VK_CLEAR )
			||
			( vk == VK_SHIFT )
			||
			( vk == VK_CONTROL )
			||
			( vk == VK_MENU )
			||
			( vk == VK_PAUSE )
			||
			( vk == VK_CAPITAL )
			||
			( vk == VK_NUMLOCK )
			||
			( vk == VK_SCROLL )
		)
		{

			break;

		} else
		if ( vk == VK_BACK )
		{

			p->size_font = p->size / 7;

			n_posix_sprintf_literal( p->str_key, "%s", n_posix_literal( "Backspace" ) );

		} else
		if ( vk == VK_RETURN )
		{

			p->size_font = p->size / 5;

			n_posix_sprintf_literal( p->str_key, "%s", n_posix_literal( "Enter" ) );

		} else
		if ( vk == VK_PRIOR )
		{

			p->size_font = p->size / 4;

			n_posix_sprintf_literal( p->str_key, "%s", n_posix_literal( "PgUp" ) );

		} else
		if ( vk == VK_NEXT )
		{

			p->size_font = p->size / 4;

			n_posix_sprintf_literal( p->str_key, "%s", n_posix_literal( "PgDn" ) );

		} else
		if ( vk == VK_END )
		{

			p->size_font = p->size / 4;

			n_posix_sprintf_literal( p->str_key, "%s", n_posix_literal( "End" ) );

		} else
		if ( vk == VK_HOME )
		{

			p->size_font = p->size / 4;

			n_posix_sprintf_literal( p->str_key, "%s", n_posix_literal( "Home" ) );

		} else
		if ( vk == VK_LEFT )
		{

			p->size_font = p->size / 5;

			n_posix_sprintf_literal( p->str_key, "%s", n_posix_literal( "Left" ) );

		} else
		if ( vk == VK_UP )
		{

			p->size_font = p->size / 5;

			n_posix_sprintf_literal( p->str_key, "%s", n_posix_literal( "Up" ) );

		} else
		if ( vk == VK_RIGHT )
		{

			p->size_font = p->size / 5;

			n_posix_sprintf_literal( p->str_key, "%s", n_posix_literal( "Right" ) );

		} else
		if ( vk == VK_DOWN )
		{

			p->size_font = p->size / 5;

			n_posix_sprintf_literal( p->str_key, "%s", n_posix_literal( "Down" ) );

		} else
		if ( vk == VK_INSERT )
		{

			p->size_font = p->size / 3;

			n_posix_sprintf_literal( p->str_key, "%s", n_posix_literal( "Ins" ) );

		} else
		if ( vk == VK_DELETE )
		{

			p->size_font = p->size / 3;

			n_posix_sprintf_literal( p->str_key, "%s", n_posix_literal( "Del" ) );

		} else
		if ( vk == VK_SPACE )
		{

			p->size_font = p->size / 5;

			n_posix_sprintf_literal( p->str_key, "%s", n_posix_literal( "Space" ) );

		} else {

			p->size_font = (n_type_gfx) ( (n_type_real) p->size * 0.75 );

			if ( n_win_is_input( VK_SHIFT ) )
			{

				if (
					( vk >= n_posix_literal( 'A' ) )
					&&
					( vk <= n_posix_literal( 'Z' ) )
				)
				{
					n_posix_sprintf_literal( p->str_key, "%c", vk );
				} else {
					n_typing_input( vk, p->str_key );
				}

			} else {

				if (
					( vk >= n_posix_literal( 'A' ) )
					&&
					( vk <= n_posix_literal( 'Z' ) )
				)
				{
					int offset = n_posix_literal( 'a' ) - n_posix_literal( 'A' );
					n_posix_sprintf_literal( p->str_key, "%c", vk + offset );
				} else {
					n_typing_input( vk, p->str_key );
				}

			}

		}
//n_win_hwndprintf_literal( hwnd, "%d", vk );


		if ( p->percent != 0 )
		{
			p->percent = 0;

			n_bmp_flush_fastcopy( &p->bmp_new, &p->bmp_old );
		}

		n_win_timer_init( hwnd, p->timer_id, 1 );

	}
	break;

	case WM_KEYUP :
	{

		p->rapid_fire = 0;


		if ( p->percent != 0 ) { break; }


		int vk = (int) wparam;

		if (
			( vk == VK_TAB )
			||
			( vk == VK_CLEAR )
			||
			( vk == VK_SHIFT )
			||
			( vk == VK_CONTROL )
			||
			( vk == VK_MENU )
			||
			( vk == VK_PAUSE )
			||
			( vk == VK_CAPITAL )
			||
			( vk == VK_NUMLOCK )
			||
			( vk == VK_SCROLL )
		)
		{

			break;

		}

		n_typing_midi_note_off( p, 0 );

	}
	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_bmp_free_fast( &p->bmp_buf );
		n_bmp_free_fast( &p->bmp_old );
		n_bmp_free_fast( &p->bmp_new );

		n_hmidiout_exit();

		n_game_timegettime_exit();

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, n_typing_wndproc );
}

#endif // #ifndef NONNON_APPS

