// Tutorial
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/project/define_unicode.c"




#include "../nonnon/win32/win_simplemenu.c"
#include "../nonnon/win32/win_titlemenu.c"


#include "../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND             hmenu = NULL;
	static n_win_simplemenu nmenu;
	static n_win_titlemenu  tmenu;


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_win_exedir2curdir();

		n_win_ime_disable( hwnd );

		n_project_darkmode();
//n_win_darkmode_onoff = n_posix_true;
//n_win_fluent_ui_onoff = n_posix_false;


		// Window

		n_win_init_literal( hwnd, "Nonnon", "", "" );


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		{ // Menu

		n_win_simplemenu_zero( &nmenu );
		n_win_simplemenu_init( &nmenu );

		n_posix_char *rc   = n_posix_literal( "B_BITMAP"    );
		n_posix_char *key1 = n_posix_literal( "Ctrl+A"      );
		n_posix_char *key2 = n_posix_literal( "Ctrl+Shift+B");

		n_win_simplemenu_set( &nmenu, 0, NULL, n_posix_literal( "[ ]Normal"   ), NULL );
		n_win_simplemenu_set( &nmenu, 1, NULL, n_posix_literal( "[x]Disabled" ), NULL );
		n_win_simplemenu_set( &nmenu, 2, NULL, n_posix_literal( "[H]Header 1" ), NULL );
		n_win_simplemenu_set( &nmenu, 3, NULL, n_posix_literal( "[V]Check"    ), NULL );
		n_win_simplemenu_set( &nmenu, 4, NULL, n_posix_literal( "[H]Header 2" ), NULL );
		n_win_simplemenu_set( &nmenu, 5, NULL, n_posix_literal( "[O]Radio 1"  ), NULL );
		n_win_simplemenu_set( &nmenu, 6, NULL, n_posix_literal( "[ ]Radio 2"  ), NULL );
		n_win_simplemenu_set( &nmenu, 7, NULL, n_posix_literal( "[-]"         ), NULL );
		n_win_simplemenu_set( &nmenu, 8,   rc, n_posix_literal( "[v]Bitmap"   ), key1 );
		n_win_simplemenu_set( &nmenu, 9,   rc, n_posix_literal( "[X]Disabled" ), key2 );

		} // Menu


		n_win_titlemenu_init_main( &tmenu, hwnd, &nmenu );


		// Size

		{
			n_type_gfx desktop; n_win_desktop_size( &desktop, NULL );
			desktop = (n_type_real) desktop * 0.125;

			n_win_set( hwnd, NULL, desktop,desktop, N_WIN_SET_CENTERING );
		}


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_RBUTTONUP :

		if ( IsWindow( hmenu ) ) { break; }

		n_win_simplemenu_show( &nmenu, hwnd );

	break;


	case WM_COMMAND :
//n_win_hwndprintf_literal( hwnd, " %x %x %x %x ", (HWND) lparam, hmenu, tmenu.hwnd_menu, tmenu.hwnd );

		if ( (HWND) lparam == nmenu.hwnd )
		{
//n_win_hwndprintf_literal( hwnd, "Normal : %d %d", nmenu.focus, wparam );

			static n_posix_bool rearrange_check = n_posix_false;
			static n_posix_bool rearrange_radio = n_posix_false;
			static n_posix_bool rearrange_bmp   = n_posix_false;

			static n_posix_bool radio_status    = 0;

			if ( wparam == N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
			{
//n_win_hwndprintf_literal( hwnd, "REARRANGE : %d", nmenu.focus );

				if ( rearrange_check )
				{
					rearrange_check = n_posix_false;

					if ( n_win_simplemenu_detect_literal( &nmenu, 3, 'V' ) )
					{
						n_win_simplemenu_tweak_literal( &nmenu, 3, ' ' );
					} else {
						n_win_simplemenu_tweak_literal( &nmenu, 3, 'V' );
					}
				}

				if ( rearrange_radio )
				{
					rearrange_radio = n_posix_false;

					if ( radio_status == 0 )
					{
						n_win_simplemenu_tweak_literal( &nmenu, 5, 'O' );
						n_win_simplemenu_tweak_literal( &nmenu, 6, ' ' );
					} else {
						n_win_simplemenu_tweak_literal( &nmenu, 5, ' ' );
						n_win_simplemenu_tweak_literal( &nmenu, 6, 'O' );
					}
				}

				if ( rearrange_bmp )
				{
					rearrange_bmp = n_posix_false;

					if ( n_win_simplemenu_detect_literal( &nmenu, 8, 'v' ) )
					{
						n_win_simplemenu_tweak_literal( &nmenu, 8, ' ' );
					} else {
						n_win_simplemenu_tweak_literal( &nmenu, 8, 'v' );
					}
				}

			} else
			if ( wparam == 3 )
			{
				rearrange_check = n_posix_true;
			} else
			if ( wparam == 5 )
			{
				rearrange_radio = n_posix_true;

				if ( n_win_simplemenu_detect_literal( &nmenu, 5, 'O' ) )
				{
					radio_status = 0;
				} else
				if ( n_win_simplemenu_detect_literal( &nmenu, 6, 'O' ) )
				{
					radio_status = 0;
				}
			} else
			if ( wparam == 6 )
			{
				rearrange_radio = n_posix_true;

				if ( n_win_simplemenu_detect_literal( &nmenu, 5, 'O' ) )
				{
					radio_status = 1;
				} else
				if ( n_win_simplemenu_detect_literal( &nmenu, 6, 'O' ) )
				{
					radio_status = 1;
				}
			} else
			if ( wparam == 8 )
			{
				rearrange_bmp = n_posix_true;
			}// else

		}

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		nmenu.is_window = n_posix_false;

		n_win_titlemenu_exit( &tmenu );

		n_win_simplemenu_exit( &nmenu );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


