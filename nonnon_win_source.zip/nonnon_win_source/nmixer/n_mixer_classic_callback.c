// nmixer
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




LRESULT CALLBACK
n_mixer_classic_callback_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case MM_MIXM_CONTROL_CHANGE :
	{

		int vol = 0; n_mixer_get( &vol );

		n_nmixer_systray_icon_change_percent = vol;
		n_win_systray_icon_change( &nmixer.nid, nmixer.icon_name, nmixer.icon_index, n_nmixer_icon_supported );
	}
	break;


	} // switch


	return 0;
}

n_bool
n_mixer_classic_callback_onoff( n_bool is_init )
{

	static HMIXER hmixer = NULL;

	if ( is_init )
	{

		UINT id_max = mixerGetNumDevs();
		if ( id_max == 0 ) { return n_true; }

		UINT id = 0;
		n_posix_loop
		{

			mixerOpen( &hmixer, id, (DWORD_PTR) nmixer.hwnd, 0, CALLBACK_WINDOW );
			if ( hmixer != NULL ) { break; }

			id++;
			if ( id >= id_max ) { return n_true; }
		}

	} else {

		mixerClose( hmixer );
		hmixer = NULL;

	}


	return n_false;
}


