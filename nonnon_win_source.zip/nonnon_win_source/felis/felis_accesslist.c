// Felis
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




static n_bool       n_felis_accesslist_onoff = n_false;
static n_win_txtbox n_felis_accesslist_txtbox[ 2 ];
static n_txt        n_felis_accesslist_txt;
static n_bool       n_felis_accesslist_txt_is_loaded = n_false;




void
n_felis_accesslist_load( void )
{

	n_posix_char *bl  = n_posix_literal( "./blocklist.txt" );
	n_win_txtbox *tbx = &n_felis_accesslist_txtbox[ 1 ];
	n_txt        *txt = &tbx->txt;


	n_txt_load( txt, bl );

	n_txt_copy( txt, &n_felis_accesslist_txt );
	n_felis_accesslist_txt_is_loaded = n_true;


	n_type_int i = 0;
	while( txt->sy > 1 )
	{

		n_posix_char *line = n_txt_get( txt, i );

		if ( n_string_is_empty( line ) )
		{
			n_win_txtbox_line_del( tbx, i );
			i--;
		}


		i++;
		if ( i >= txt->sy ) { break; }
	}


	n_txt_sort_up( txt );


	return;
}

void
n_felis_accesslist_save( void )
{

	n_posix_char *bl  = n_posix_literal( "./blocklist.txt" );
	n_win_txtbox *tbx = &n_felis_accesslist_txtbox[ 1 ];
	n_txt        *txt = &tbx->txt;


	n_type_int i = 0;
	while( txt->sy > 1 )
	{

		n_posix_char *line = n_txt_get( txt, i );

		if ( n_string_is_empty( line ) )
		{
			n_win_txtbox_line_del( tbx, i );
			i--;
		}


		i++;
		if ( i >= txt->sy ) { break; }
	}


	n_txt_sort_up( txt );


	if (
		( n_false == n_txt_is_empty( txt ) )
		||
		( n_posix_stat_is_exist( bl ) )
	)
	{
		if (
			( n_felis_accesslist_txt_is_loaded )
			&&
			( n_false == n_txt_is_same( txt, &n_felis_accesslist_txt ) )
		)
		{
//n_posix_debug_literal( "%d", txt->sy );
			n_txt_save( txt, bl );
			n_txt_free( &n_felis_accesslist_txt );
			n_txt_copy( txt, &n_felis_accesslist_txt );
		}
	}


	return;
}

void
n_felis_accesslist_show( void )
{

	if ( n_felis_accesslist_onoff )
	{
/*
		LOGFONT lf; ZeroMemory( &lf, sizeof( LOGFONT ) );
		n_posix_sprintf_literal
		(
			lf.lfFaceName,
			"%s",
			n_gdi_font_find
			(
				n_posix_literal( "Consolas" ),
				n_posix_literal( "FixedSys" )
			)
		);
		lf.lfPitchAndFamily = FIXED_PITCH | FF_MODERN;

		HFONT hf = n_win_font_logfont2hfont( &lf );//GetStockObject( SYSTEM_FIXED_FONT )
		

		n_win_font_set( H_ACCESS, hf, n_false );
		n_win_font_set( H_BLOCK , hf, n_false );
*/
		ShowWindow( H_FRAME , SW_HIDE   );
		ShowWindow( H_ACCESS, SW_NORMAL );
		ShowWindow( H_BLOCK , SW_NORMAL );

	} else {

		n_felis_accesslist_save();

		ShowWindow( H_ACCESS, SW_HIDE   );
		ShowWindow( H_BLOCK , SW_HIDE   );
		ShowWindow( H_FRAME , SW_NORMAL );

	}


	return;
}

void
n_felis_accesslist_init( HWND hwnd )
{

	int style = 
		N_WIN_TXTBOX_STYLE_EDITBOX |
		N_WIN_TXTBOX_STYLE_VSCROLL |
		N_WIN_TXTBOX_STYLE_HSCROLL |
		N_WIN_TXTBOX_STYLE_STRIPED
	;

	if ( n_sysinfo_version_vista_or_later() )
	{
		style |= N_WIN_TXTBOX_STYLE_VISIBLE;
	}

	n_win_txtbox_zero( &n_felis_accesslist_txtbox[ 0 ] );
	n_win_txtbox_zero( &n_felis_accesslist_txtbox[ 1 ] );

	n_win_txtbox_init( &n_felis_accesslist_txtbox[ 0 ], hwnd, style, 0 );
	n_win_txtbox_init( &n_felis_accesslist_txtbox[ 1 ], hwnd, style, 0 );

	H_ACCESS = n_felis_accesslist_txtbox[ 0 ].hwnd;
	H_BLOCK  = n_felis_accesslist_txtbox[ 1 ].hwnd;

	n_win_stdfont_init( &H_ACCESS, 1 );
	n_win_stdfont_init( &H_BLOCK , 1 );

	n_felis_accesslist_txtbox[ 0 ].txt.readonly = N_TXT_READONLY_ON;
	//n_felis_accesslist_txtbox[ 1 ].txt.readonly = N_TXT_READONLY_ON;

	n_felis_accesslist_load();


	return;
}

void
n_felis_accesslist_line_set( n_posix_char *str )
{

	n_win_txtbox_line_set( &n_felis_accesslist_txtbox[ 0 ], 0, str );
	n_win_txtbox_refresh( &n_felis_accesslist_txtbox[ 0 ], 0 );

	return;
}

int
n_felis_accesslist_loop( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	int ret = 0;

	ret += n_win_txtbox_proc( hwnd, msg, wparam, lparam, &n_felis_accesslist_txtbox[ 0 ] );
	ret += n_win_txtbox_proc( hwnd, msg, wparam, lparam, &n_felis_accesslist_txtbox[ 1 ] );


	return ret;
}

void
n_felis_accesslist_exit( HWND hwnd )
{

	n_felis_accesslist_save();

	n_win_stdfont_exit( &H_ACCESS, 1 );
	n_win_stdfont_exit( &H_BLOCK , 1 );

	n_win_txtbox_exit( &n_felis_accesslist_txtbox[ 0 ] );
	n_win_txtbox_exit( &n_felis_accesslist_txtbox[ 1 ] );

	n_txt_free( &n_felis_accesslist_txt );


	return;
}

n_bool
n_felis_accesslist_is_blocklisted( const BSTR url )
{

	n_posix_char *s = n_com_bstr2string( url );


	n_bool ret = n_false;


	n_txt *txt = &n_felis_accesslist_txtbox[ 1 ].txt;


	n_type_int i = 0;
	while( txt->sy )
	{
//n_posix_debug_literal( "%s : %s", s, n_txt_get( txt, i ) );

		if ( n_string_search_simple( s, n_txt_get( txt, i ) ) )
		{
			ret = n_true;
			break;
		}

		i++;
		if ( i >= txt->sy ) { break; }
	}


	if ( txt->sy )
	{

		n_type_int    l = n_posix_strlen( s ) + n_posix_strlen_literal( "[o] : " );
		n_posix_char *t = n_string_new_fast( l );

		if ( ret )
		{
			n_posix_sprintf_literal( t, "[x] : %s", s );
		} else {
			n_posix_sprintf_literal( t, "[o] : %s", s );
		}

		n_felis_accesslist_line_set( t );

		n_memory_free( t );

	}


	n_memory_free( s );


	return ret;
}


