// Marie
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




static n_win_grab_n_drag n_marie_grab_n_drag;




void
n_marie_grab_n_drag_redraw( HWND hwnd )
{

	extern void n_marie_window_refresh( HWND, n_bmp*, int );
	extern void n_marie_client_refresh( HWND, n_bmp* );


	{

		n_type_gfx scrmax_x = n_marie_n_win.rcsx - n_marie_n_win.csx;
		n_type_gfx scrmax_y = n_marie_n_win.rcsy - n_marie_n_win.csy;

		if ( n_marie_n_win.scrollx <        0 ) { n_marie_n_win.scrollx =        0; }
		if ( n_marie_n_win.scrolly <        0 ) { n_marie_n_win.scrolly =        0; }
		if ( n_marie_n_win.scrollx > scrmax_x ) { n_marie_n_win.scrollx = scrmax_x; }
		if ( n_marie_n_win.scrolly > scrmax_y ) { n_marie_n_win.scrolly = scrmax_y; }

	}


	n_marie_hscr.unit_pos = n_marie_n_win.scrollx;
	n_marie_vscr.unit_pos = n_marie_n_win.scrolly;

	n_marie_client_refresh( hwnd, n_marie_bmp_main );

	n_win_scrollbar_draw_always( &n_marie_hscr, n_true );
	n_win_scrollbar_draw_always( &n_marie_vscr, n_true );


	return;
}

void
n_marie_grab_n_drag_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_MBUTTONDOWN :
/*
		if (
			( n_marie_n_win.csx == n_marie_n_win.rcsx )
			&&
			( n_marie_n_win.csy == n_marie_n_win.rcsy )
		)
		{
			break;
		}
*/
		n_win_cursor_add( NULL, IDC_SIZEALL );
		SetCapture( hwnd );

		n_win_grab_n_drag_zero( &n_marie_grab_n_drag );
		n_win_grab_n_drag_init( &n_marie_grab_n_drag, hwnd );

	break;

	case WM_MOUSEMOVE :
	{

		int dx,dy;
		if ( n_win_grab_n_drag_loop( &n_marie_grab_n_drag, &dx, &dy ) ) { break; }

		n_marie_n_win.scrollx += dx;
		n_marie_n_win.scrolly += dy;

		n_marie_grab_n_drag_redraw( hwnd );

	}
	break;


	case WM_MBUTTONUP :

		ReleaseCapture();

		n_win_grab_n_drag_exit( &n_marie_grab_n_drag );

	break;


	case WM_TIMER :
	{

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		int dx,dy;
		if ( n_win_grab_n_drag_inertia( &n_marie_grab_n_drag, wparam, &dx, &dy ) ) { break; }

		n_marie_n_win.scrollx += dx;
		n_marie_n_win.scrolly += dy;

		n_marie_grab_n_drag_redraw( hwnd );

	}
	break;


	} // switch


	return;
}

