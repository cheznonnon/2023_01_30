// Nonnon Freecell
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_freecell_watcher( n_freecell *p )
{
//return;

	n_posix_char *icon_name = n_win_exepath_new();


	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sx              = 0;
	gdi.sy              = 0;
	gdi.scale           = N_GDI_SCALE_AUTO;
	gdi.style           = 0;
	gdi.layout          = N_GDI_LAYOUT_VERTICAL;
	gdi.align           = N_GDI_ALIGN_CENTER;

	gdi.base_color_bg   = 0;
	gdi.base_color_fg   = 0;
	gdi.base_style      = N_GDI_BASE_SOLID;
	gdi.base_unit       = 0;

	gdi.frame_style     = N_GDI_FRAME_BUTTON;

	gdi.icon            = icon_name;
	gdi.icon_index      = N_GAMECONSOLE_ICON_OFFSET_FREECELL;
	gdi.icon_style      = N_GDI_ICON_RESOURCE;

//n_game_hwndprintf_literal( " %d ", p->cardgen.card_sy / 4 );
	if ( ( p->cardgen.card_sy / 4 ) >= 64 )
	{
		gdi.icon_rsrc = 64;
	} else
	if ( ( p->cardgen.card_sy / 4 ) >= 48 )
	{
		gdi.icon_rsrc = 48;
	} else {
		gdi.icon_rsrc = 32;
	}

	n_gdi_bmp( &gdi, &p->bmp_neko_l );
	gdi.icon_index++;
	n_gdi_bmp( &gdi, &p->bmp_neko_r );


	n_string_path_free( icon_name );


	return;
}


