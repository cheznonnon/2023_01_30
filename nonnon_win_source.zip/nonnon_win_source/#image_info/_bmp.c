// Nonnon Image Info
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_imageinfo_bmp( n_posix_char *name, n_win_txtbox *txtbox )
{

	int cb_f = sizeof( BITMAPFILEHEADER );
	int cb_i = sizeof( BITMAPINFOHEADER );

	if ( ( cb_f + cb_i ) > n_posix_stat_size( name ) ) { return; }


	BITMAPFILEHEADER f;
	BITMAPINFOHEADER i;


	FILE *fp = n_posix_fopen_read( name );
	if ( fp != NULL )
	{
		fread( &f, cb_f, 1, fp );
		fread( &i, cb_i, 1, fp );
	}
	fclose( fp );


	n_posix_char *str = n_string_new( 1024 );


	n_posix_sprintf_literal
	(
		str,

		"[ BITMAPFILEHEADER ]\n"
		"u16 bfType          = %c%c\n"
		"u32 bfSize          = %lu\n"
		"u16 bfReserved1     = %d\n"
		"u16 bfReserved2     = %d\n"
		"u32 bfOffBits       = %lu\n"
		"\n"
		"[ BITMAPINFOHEADER ]\n"
		"u32 biSize          = %lu\n"
		"s32 biWidth         = %ld\n"
		"s32 biHeight        = %ld\n"
		"u16 biPlanes        = %d\n"
		"u16 biBitCount      = %d\n"
		"u32 biCompression   = %lu\n"
		"u32 biSizeImage     = %lu\n"
		"s32 biXPelsPerMeter = %ld\n"
		"s32 biYPelsPerMeter = %ld\n"
		"u32 biClrUsed       = %lu\n"
		"u32 biClrImportant  = %lu\n",

		f.bfType & 0x00ff, ( f.bfType >> 8 ) & 0xff,
		f.bfSize,
		f.bfReserved1,
		f.bfReserved2,
		f.bfOffBits,

		i.biSize,
		i.biWidth,
		i.biHeight,
		i.biPlanes,
		i.biBitCount,
		i.biCompression,
		i.biSizeImage,
		i.biXPelsPerMeter,
		i.biYPelsPerMeter,
		i.biClrUsed,
		i.biClrImportant
	);


	n_win_txtbox_txt_load_onmemory( txtbox, str, 1024 );


	return;
}


