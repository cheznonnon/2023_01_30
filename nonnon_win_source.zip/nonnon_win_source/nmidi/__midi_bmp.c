// nmidi
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [Mechanism]
//
//	X : [ 0 : header ] [ 1 : note ] [ 2 : note ] ...
//	Y : [ 0 ] - [ 15 ]
//
//	don't use channel #15 although it will be allocated




#include  "../nonnon/neutral/bmp/all.c"
#include  "../nonnon/neutral/midi.c"




#define n_midi_bmp_color2channel n_bmp_r
#define n_midi_bmp_color2sound   n_bmp_g
#define n_midi_bmp_color2panpot  n_bmp_b
#define n_midi_bmp_color2note    n_bmp_g
#define n_midi_bmp_color2volume  n_bmp_b

#define n_midi_bmp_free( bmp ) n_bmp_free( bmp )

void
n_midi_bmp_new( n_bmp *bmp, int quarters )
{

	const int hdr  = 1;
	const int unit = N_MIDI_TIMEBASE;

	n_bmp_new_fast( bmp, hdr + ( unit * quarters ), N_MIDI_CHANNEL_MAX );
	n_bmp_flush( bmp, 0 );


	int i = 0;
	n_posix_loop
	{

		u32 color = 0;
		n_bmp_ptr_get_fast( bmp, 0, i, &color );

		int a = n_bmp_a( color );
		int r = i;//n_bmp_r( color );
		int g = n_bmp_g( color );
		int b = N_MIDI_PANPOT_CENTER;//n_bmp_b( color );

		color = n_bmp_argb( a,r,g,b );

		n_bmp_ptr_set_fast( bmp, 0, i,  color );

		i++;
		if ( i >= N_MIDI_CHANNEL_MAX ) { break; }
	}


	return;
}

void
n_midi_bmp_save( const n_bmp *bmp, const n_posix_char *name )
{

	// [x] : currently broken


	n_txt txt; n_txt_zero( &txt ); n_txt_new( &txt );


	n_type_int cch = N_BMP_SX( bmp ) * n_posix_strlen_literal( "C( 00, 000 ) P( 000 ) " );
	if ( cch > LONG_MAX ) { return; }

	n_posix_char *s = n_string_new_fast( cch );

	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_type_gfx i = 0;
	n_posix_loop
	{

		u32 clr = 0; n_bmp_ptr_get_fast( bmp, x, y, &clr );


		if ( x == 0 )
		{

			i += n_posix_sprintf_literal
			(
				&s[ i ],
				"C( %2d, %3d ) P( %3d ) ",
				(int) n_midi_bmp_color2channel( clr ),
				(int) n_midi_bmp_color2sound  ( clr ),
				(int) n_midi_bmp_color2panpot ( clr )
			);

		} else {

			n_type_gfx xx = 0;
			n_posix_loop
			{

				u32 c = 0; n_bmp_ptr_get_fast( bmp, x + 1 + xx, y, &c );
				if ( c != clr ) { break; }

				xx++;
				if ( ( x + 1 + xx ) >= N_BMP_SX( bmp ) ) { break; }
			}

			x += xx;

			i += n_posix_sprintf_literal
			(
				&s[ i ],
				"V( %3d ) %3d( %3d ) ",
				(int) 100,//n_midi_bmp_color2volume( clr ),
				(int) n_midi_bmp_color2note  ( clr ),
				(int) xx
			);

		}


		x++;
		if ( x >= N_BMP_SX( bmp ) )
		{

			x = i = 0;

			n_txt_add( &txt, txt.sy, s );
			n_string_zero( s, cch );

			y++;
			if ( y >= N_BMP_SY( bmp ) ) { break; }
		}
	}

	n_memory_free( s );


	n_txt_save( &txt, name );
	n_txt_free( &txt );


	return;
}

void
n_midi_bmp_resize( n_bmp *bmp, int quarters_delta )
{

	const int hdr  = 1;
	const int unit = N_MIDI_TIMEBASE;


	n_type_gfx quarters = ( N_BMP_SX( bmp ) - hdr ) / unit;

	quarters = n_posix_max_n_type_gfx( 1, quarters + quarters_delta );

//n_posix_debug_literal( "%d", quarters );

	n_bmp_resizer( bmp, hdr + ( unit * quarters ), N_MIDI_CHANNEL_MAX, 0, N_BMP_RESIZER_NORMAL );


	return;
}

void
n_midi_bmp_channel_get( const n_bmp *bmp, int ch, int *ret_ch, int *ret_sound, int *ret_panpot )
{

	u32 color = 0;
	n_bmp_ptr_get( bmp, 0, ch, &color );

	if ( ret_ch     != NULL ) { *ret_ch     = n_midi_bmp_color2channel( color ); }
	if ( ret_sound  != NULL ) { *ret_sound  = n_midi_bmp_color2sound  ( color ); }
	if ( ret_panpot != NULL ) { *ret_panpot = n_midi_bmp_color2panpot ( color ); }


	return;
}

void
n_midi_bmp_note_get( const n_bmp *bmp, int ch, int index, int *ret_note, int *ret_volume )
{

	u32 color = 0;
	n_bmp_ptr_get( bmp, index, ch, &color );

	if ( ret_note   != NULL ) { *ret_note   = n_midi_bmp_color2note  ( color ); }
	if ( ret_volume != NULL ) { *ret_volume = n_midi_bmp_color2volume( color ); }


	return;
}

void
n_midi_bmp_channel_set( n_bmp *bmp, n_type_gfx ch, n_type_gfx sound, n_type_gfx panpot )
{

	// [!] : -1 means "no touch"


	u32 color = 0;

	n_bmp_ptr_get( bmp, 0, ch, &color );

	int a = n_bmp_a( color );
	int r = n_bmp_r( color );
	int g = n_bmp_g( color );
	int b = n_bmp_b( color );

	if (     ch != -1 ) { r =     ch; }
	if (  sound != -1 ) { g =  sound; }
	if ( panpot != -1 ) { b = panpot; }

	color = n_bmp_argb( a,r,g,b );

	n_bmp_ptr_set( bmp, 0, ch,  color );


	return;
}

void
n_midi_bmp_note_set( n_bmp *bmp, n_type_gfx ch, n_type_gfx index_from, n_type_gfx index_to, n_type_gfx note, n_type_gfx volume )
{

	// [!] : -1 means "no touch"


	n_type_gfx fx = index_from;
	n_type_gfx tx = index_to;
	n_posix_loop
	{

		u32 color = 0;

		n_bmp_ptr_get( bmp, fx, ch, &color );

		int a = n_bmp_a( color );
		int r = n_bmp_r( color );
		int g = n_bmp_g( color );
		int b = n_bmp_b( color );

		if ( note   != -1 ) { g =   note; }
		if ( volume != -1 ) { b = volume; }

		color = n_bmp_argb( a,r,g,b );

		n_bmp_ptr_set( bmp, fx, ch,  color );


		fx++;
		if ( fx >= tx ) { break; }
	}


	return;
}

n_type_gfx
n_midi_bmp_channel_detect( n_bmp *bmp )
{

	n_type_gfx used_channels = 0;


	n_type_gfx ch = 0;
	n_posix_loop
	{

		n_type_gfx n = 1;
		n_posix_loop
		{

			u32 color;
			n_bmp_ptr_get( bmp, n, ch, &color );

			if ( color != 0 )
			{
				used_channels++;
				break;
			}

			n++;
			if ( n >= N_BMP_SX( bmp ) ) { break; }
		}

		ch++;
		if ( ch >= N_MIDI_CHANNEL_MAX ) { break; }
	}


	return used_channels;
}

n_type_gfx
n_midi_bmp_beat_detect( n_bmp *bmp )
{

	n_type_gfx same_min = N_BMP_SX( bmp ) - 1;


	n_type_gfx ch = 0;
	n_posix_loop
	{

		n_type_gfx same_cur = 1;
		u32 note_prv = 0;
		u32 note_cur = 0;

		n_bmp_ptr_get( bmp, 1, ch, &note_prv );

		n_type_gfx n = 1;
		n_posix_loop
		{

			n_bmp_ptr_get( bmp, n, ch, &note_cur );

			if ( note_prv == note_cur )
			{
				same_cur++;
			} else {
				same_min = n_posix_min_n_type_gfx( same_min, same_cur );
				same_cur = 1;
			}

			note_prv = note_cur;


			n++;
			if ( n >= N_BMP_SX( bmp ) ) { break; }
		}

		ch++;
		if ( ch >= N_MIDI_CHANNEL_MAX ) { break; }
	}


	return same_min;
}

n_type_gfx
n_midi_bmp_param_clamp( n_type_gfx p )
{

	const n_type_gfx minim = 0;
	const n_type_gfx maxim = N_MIDI_PARAM_MAX - 1;

	p = n_posix_minmax( minim, maxim, p );


	return p;
}

