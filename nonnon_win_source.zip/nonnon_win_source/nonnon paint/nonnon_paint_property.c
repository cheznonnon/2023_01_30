// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




n_type_int
n_paint_bmp_usedcolors_detect( n_paint_layer *p )
{

	n_type_int layer_count = 1;
	if ( n_paint_layer_onoff ) { layer_count = n_paint_layer_count; }
//n_posix_debug_literal( " %d ", layer_count ); return 0;


	const n_type_int pxls = N_BMP_SX( &p[ 0 ].bmp_data ) * N_BMP_SY( &p[ 0 ].bmp_data );
	const n_type_int byte = pxls * layer_count * sizeof( n_type_int );
//n_posix_debug_literal( " %d ", pxls ); return 0;


	u32        *pal   = n_memory_new_closed( byte );
	n_type_int  count = 0;


	n_memory_zero( pal, byte );


	n_type_int layer_index = 0;
	n_posix_loop
	{

		// [!] : histogram

		n_type_int i = 0;
		n_posix_loop
		{//break;

			u32 color = N_BMP_PTR( &p[ layer_index ].bmp_data )[ i ];


			n_type_int j = 0;
			n_posix_loop
			{//break;

				// [Needed] : for the first color

				if ( j >= count )
				{
					pal[ j ] = color;
					count++;
					break;
				}


				if ( pal[ j ] == color )
				{
					break;
				}

				j++;

			}


			i++;
			if ( i >= pxls ) { break; }
		}


		layer_index++;
		if ( layer_index >= layer_count ) { break; }

	}


	n_memory_free_closed( pal );


	return count;
}

void
n_paint_property_usedcolors( n_paint_layer *p )
{

	n_posix_char str_colors[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_colors, n_paint_bmp_usedcolors_detect( p ) );

	n_posix_char str[ 100 ];
	n_posix_sprintf_literal( str, "Used Colors : %s", str_colors );

	n_paint_dialog_info( str );


	return;
}


