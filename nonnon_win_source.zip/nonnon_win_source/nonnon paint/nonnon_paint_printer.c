// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include <commdlg.h>




// internal
void
n_paint_printer_bitmap( HWND hwnd, HDC hdc, n_type_gfx sx, n_type_gfx sy )
{

	n_bmp bmp; n_bmp_zero( &bmp );


	n_type_gfx bmpsx = N_BMP_SX( n_paint_bmp_data );
	n_type_gfx bmpsy = N_BMP_SY( n_paint_bmp_data );

	if ( n_paint_layer_onoff == n_false )
	{
		n_bmp_carboncopy( n_paint_bmp_data, &bmp );
	} else {
		n_bmp_new( &bmp, bmpsx, bmpsy );
		n_bmp_layercopy( n_paint_layer_data, &bmp, 0,0, bmpsx,bmpsy, 0,0, n_false );
	}


	n_type_gfx canvas_min = n_posix_min(    sx,    sy );
	n_type_gfx bitmap_min = n_posix_min( bmpsx, bmpsy );

	if ( canvas_min > bitmap_min )
	{
		int scale = canvas_min / bitmap_min;
		n_bmp_scaler_big( &bmp, scale );
	} else
	if ( canvas_min < bitmap_min )
	{
		int scale = bitmap_min / canvas_min;
		n_bmp_smoothshrink( &bmp, scale );
	}

	n_bmp_resizer( &bmp, sx,sy, n_bmp_white, N_BMP_RESIZER_CENTER );


	n_gdi_bitmap_draw_main( hwnd, hdc, &bmp, 0,0,sx,sy, 0,0 );


	n_bmp_free_fast( &bmp );


	return;
}

void
n_paint_printer( HWND hwnd )
{

	PRINTDLG pd; ZeroMemory( &pd, sizeof( PRINTDLG ) );

	pd.lStructSize = sizeof( PRINTDLG );
	pd.hwndOwner   = hwnd;
	pd.Flags       = PD_RETURNDC | PD_HIDEPRINTTOFILE | PD_DISABLEPRINTTOFILE | PD_NOSELECTION;

	if ( PrintDlg( &pd ) )
	{

		HDC hdc = pd.hDC;


		DOCINFO di; ZeroMemory( &di,sizeof( DOCINFO ) );
		di.cbSize = sizeof( DOCINFO );

		StartDoc( hdc, &di );


		n_win_cursor_add( NULL, IDC_WAIT );


		// [!] : HORZRES / VERTRES : unit is large pixel

		n_type_gfx sx = GetDeviceCaps( hdc, HORZRES );
		n_type_gfx sy = GetDeviceCaps( hdc, VERTRES );


		n_posix_char str_sx[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_sx, sx );
		n_posix_char str_sy[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_sy, sy );

		n_posix_char str[ 100 ]; n_posix_sprintf_literal( str, "X %s px\nY %s px", str_sx, str_sy );
		n_project_dialog_info( hwnd, str );


		n_paint_printer_bitmap( hwnd, hdc, sx,sy );


		EndDoc( hdc );


		DeleteObject( hdc );

	}


	return;
}


