



#include "../../../nonnon/neutral/filer.c"

#include "../../../nonnon/win32/explorer.c"
#include "../../../nonnon/win32/win.c"


#include "../../../nonnon/project/macro.c"




void
n_trash( void )
{

	// [Needed] : #include <shellapi.h>

	// [x] : slow like via Explorer
	//
	//	Win95 + IE4
	//	Win98/Me
	//	Win2000


	//#define SHERB_NOCONFIRMATION 1
	//#define SHERB_NOPROGRESSUI   2
	//#define SHERB_NOSOUND        4


	SHEmptyRecycleBin( NULL, NULL, 1 | 4 );


	return;
}

int
main( void )
{

	char abspath[ 1024 ];


	n_win_commandline( abspath );


	if ( n_project_dialog_yesno( NULL, "Really OK?" ) )
	{
//n_project_dialog_info( NULL, abspath );

		n_filer_remove( abspath );
		n_explorer_refresh( false );

	}


	return 0;
}

